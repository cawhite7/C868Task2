package Database;

import java.sql.ResultSet;
import java.sql.SQLException;

public class DBCreate {

    // Creates a new player in the database under the Players Table
    public static void newPlayer(String firstName, String middleName, String lastName, String birthDay) {
        String sql = "INSERT INTO Players(FirstName,MiddleName,LastName,BirthDay) VALUES ('" +
                firstName + "','" + middleName + "','" + lastName + "','" + birthDay + "');";
        DBExecuteSQL.execute(sql);
    }

    /* Runs this function when the Add Player to Roster button is clicked under the
        Add Player view in the GUI
     */
    public static void addPlayerToRoster(int yearID, int playerID, int age) throws SQLException {
        String teamName = null;
        String sql = "SELECT TeamName FROM Years WHERE YearID=" + yearID + ";";
        ResultSet rs = DBExecuteSQL.executeQuery(sql);
        while (rs.next()) {
            teamName = rs.getString("TeamName");
        }
        String sql2 = "INSERT INTO Rosters(YearID,TeamName,PlayerID,Age) " +
                "VALUES(" + yearID + ",'" + teamName + "'," + playerID + "," + age + ");";
        DBExecuteSQL.execute(sql2);
    }

    // Adds the selected player from the roster list to the injury list in the database
    public static void addPlayerToInjury(int rosterID, int jerseyNumber, String firstName, String lastName, String position) {
        String sql = "INSERT INTO Injuries(RosterID,JerseyNumber,FirstName,LastName,Position) " +
                "VALUES(" + rosterID + "," + jerseyNumber + ",'" + firstName + "','" + lastName + "','" + position + "');";
        DBExecuteSQL.execute(sql);
    }

    // Adds the selected player from the roster list to the depth chart
    public static void addPlayerToDepthChart(int rosterID, int playerID, String position, int string) {
        String sql = "INSERT INTO DepthCharts(RosterID,PlayerID,Position,String) " +
                "VALUES (" + rosterID + "," + playerID + ",'" + position + "'," + string + ");";
        DBExecuteSQL.execute(sql);
    }

    // Creates a new year in the database under the Years table
    public static void addYear(int year, String teamName) {
        String sql = "INSERT INTO Years(YearID,TeamName) VALUES (" + year + ",'" + teamName + "')";
        DBExecuteSQL.execute(sql);
    }

}
