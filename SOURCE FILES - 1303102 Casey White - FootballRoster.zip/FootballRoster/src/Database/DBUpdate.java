package Database;

import Structure.DepthCharts;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

import static Structure.Years.getYearsList;
import static Views.HomeController.yearIndex;

public class DBUpdate {

    public static void updateTeamName(String teamName, int yearID) {
        String sql = "UPDATE Years SET TeamName='" + teamName + "' WHERE YearID=" + yearID + ";";
        DBExecuteSQL.execute(sql);
    }

    public static void updatePlayer(int playerID, String firstName, String middleName, String lastName, LocalDate birthDay) {
        String sql = "UPDATE Players SET FirstName='" + firstName + "',MiddleName='" + middleName + "',LastName='" + lastName +
                     "',Birthday='" + birthDay.toString() + "' WHERE PlayerID=" + playerID + ";";
        DBExecuteSQL.execute(sql);
    }

    public static void updateRosterAge(int playerID, LocalDate birthDay) throws SQLException {
        String sql = "SELECT * FROM Rosters WHERE PlayerID=" + playerID + ";";
        ResultSet rs = DBExecuteSQL.executeQuery(sql);
        while (rs.next()) {
            String sql2 = "UPDATE Rosters SET Age=(" +
                    "select (strftime('%Y', (SELECT YearID FROM Years WHERE YearID=" + rs.getInt("YearID") + ")||'-08-01') - strftime('%Y', '" + birthDay.toString() +
                    "')) - (strftime('%m-%d', (SELECT YearID FROM Years WHERE YearID=" + rs.getInt("YearID") + ")||'-08-01') < strftime('%m-%d', '" + birthDay.toString() + "')) from Players WHERE PlayerID=" + playerID +
                    ") WHERE PlayerID=" + playerID + " AND YearID=" + rs.getInt("YearID") + ";";

            DBExecuteSQL.execute(sql2);
        }
    }

    public static void updateRosterPlayer(
            int playerID,
            int rosterID,
            int jerseyNumber,
            String firstName,
            String middleName,
            String lastName,
            LocalDate birthday,
            int height,
            int weight,
            int bench,
            int squat,
            float fortyTime,
            String position
    ) {
        String sql = "UPDATE Players SET " +
                "FirstName='" + firstName + "'," +
                "MiddleName='" + middleName + "'," +
                "LastName='" + lastName + "'," +
                "Birthday='" + birthday.toString() + "' " +
                "WHERE PlayerID=" + playerID + ";";
        DBExecuteSQL.execute(sql);

        String sql2 = "UPDATE Rosters SET " +
                "JerseyNumber=" + jerseyNumber + "," +
                "Height=" + height + "," +
                "Weight=" + weight + "," +
                "BenchPress=" + bench + "," +
                "Squat=" + squat + "," +
                "FortyTime=" + fortyTime + "," +
                "Position='" + position + "' " +
                "WHERE RosterID=" + rosterID + ";";
        DBExecuteSQL.execute(sql2);
    }

    public static void upString(DepthCharts player) throws SQLException {
        int currString = player.getString();
        String sql = "SELECT * FROM DepthCharts WHERE RosterID IN (SELECT RosterID FROM Rosters WHERE YearID=" + getYearsList().get(yearIndex).getYearID() + ") AND " +
                "Position='" + player.getPositionL() + "';";
        ResultSet rs = DBExecuteSQL.executeQuery(sql);
        while (rs.next()) {
            if (rs.getInt("String") == (currString - 1)) {
                updateString(rs.getInt("DepthChartID"), currString);
            }
        }
        updateString(player.getDepthChartID(), (currString - 1));
    }

    public static void updateString(int depthChartID, int string) {
        String sql = "UPDATE DepthCharts SET String=" + string + " WHERE DepthChartID=" + depthChartID + ";";
        DBExecuteSQL.execute(sql);
    }

    public static void downString(DepthCharts player) throws SQLException {
        int currString = player.getString();
        String sql = "SELECT * FROM DepthCharts WHERE RosterID IN (SELECT RosterID FROM Rosters WHERE YearID=" + getYearsList().get(yearIndex).getYearID() + ") AND " +
                "Position='" + player.getPositionL() + "';";
        ResultSet rs = DBExecuteSQL.executeQuery(sql);
        while (rs.next()) {
            if (rs.getInt("String") == (currString + 1)) {
                updateString(rs.getInt("DepthChartID"), currString);
            }
        }
        updateString(player.getDepthChartID(), (currString + 1));
    }

    public static void changePassword(String password) {
        String sql = "UPDATE Users SET Password='" + password + "' WHERE Username='Admin';";
        DBExecuteSQL.execute(sql);
    }

    public static void changeStrings(DepthCharts player) {
        int playerString = player.getString();
        String position = player.getPositionL();
        for (DepthCharts player2 : DepthCharts.getPositionList(position)) {
            if (player2.getString() > playerString) updateString(player2.getDepthChartID(), (player2.getString() - 1));
        }
    }

}
