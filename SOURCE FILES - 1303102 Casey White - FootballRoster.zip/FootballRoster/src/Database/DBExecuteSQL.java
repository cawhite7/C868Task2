package Database;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DBExecuteSQL {

    public static void execute(String sql) {
        try (Statement stmt = DBConnect.conn.createStatement()) {
            stmt.execute(sql);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public static ResultSet executeQuery(String sql) throws SQLException {
        Statement stmt = DBConnect.conn.createStatement();

        return stmt.executeQuery(sql);
    }

}
