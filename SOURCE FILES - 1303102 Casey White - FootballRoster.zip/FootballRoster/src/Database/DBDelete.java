package Database;

public class DBDelete {

    public static void deletePlayerFromRoster(int rosterID, int playerID) {
        String sql = "PRAGMA foreign_keys=on;";
        DBExecuteSQL.execute(sql);
        String sql2 = "DELETE FROM Rosters WHERE RosterID=" + rosterID + " AND PlayerID=" + playerID + ";";
        DBExecuteSQL.execute(sql2);
        String sql3 = "PRAGMA foreign_keys=off;";
        DBExecuteSQL.execute(sql3);
    }

    public static void deletePlayerFromInjuries(int injuryID) {
        String sql2 = "DELETE FROM Injuries WHERE InjuryID=" + injuryID + ";";
        DBExecuteSQL.execute(sql2);
    }

    public static void deleteRoster(int yearID) {
        String sql = "DELETE FROM Rosters WHERE YearID=" + yearID + ";";
        DBExecuteSQL.execute(sql);
    }

    public static void deletePlayer(int playerID) {
        String sql = "PRAGMA foreign_keys=on;";
        DBExecuteSQL.execute(sql);
        String sql2 = "DELETE FROM Players WHERE PlayerID=" + playerID + ";";
        DBExecuteSQL.execute(sql2);
        String sql3 = "PRAGMA foreign_keys=off;";
        DBExecuteSQL.execute(sql3);
    }

    public static void deleteYear(int yearID) {
        String sql = "PRAGMA foreign_keys=on;";
        DBExecuteSQL.execute(sql);
        String sql2 = "DELETE FROM Years WHERE YearID=" + yearID + ";";
        DBExecuteSQL.execute(sql2);
        String sql3 = "PRAGMA foreign_keys=off;";
        DBExecuteSQL.execute(sql3);
    }

    public static void deletePlayerFromDepthChart(int depthChartID) {
        String sql = "DELETE FROM DepthCharts WHERE DepthChartID=" + depthChartID + ";";
        DBExecuteSQL.execute(sql);
    }

}
