package Database;

import Structure.*;
import Views.HomeController;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;

import static java.lang.StrictMath.abs;

public class DBRead {

    public static void checkYearTable() throws SQLException {
        String sql = "SELECT name FROM sqlite_master WHERE type='table' AND name='Years';";
        if (!DBExecuteSQL.executeQuery(sql).next()) {
            DBCreateTables.createTables();
        }
    }

    public static String getTeamName(int yearID) throws SQLException {
        String sql = "SELECT TeamName FROM Years WHERE YearID=" + yearID + ";";
        ResultSet rs = DBExecuteSQL.executeQuery(sql);
        String returnValue = null;
        while (rs.next()) {
            returnValue = rs.getString("TeamName");
        }
        return returnValue;
    }

    public static LocalDate getBirthday(int playerID) throws SQLException {
        String sql = "SELECT Birthday FROM Players WHERE PlayerID=" + playerID + ";";
        ResultSet rs = DBExecuteSQL.executeQuery(sql);
        LocalDate returnValue = null;
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        while (rs.next()) {
            returnValue = LocalDate.parse(rs.getString("Birthday"), formatter);
        }
        return returnValue;
    }

    public static String getMiddleName(int playerID) throws SQLException {
        String sql = "SELECT MiddleName FROM Players WHERE PlayerID=" + playerID + ";";
        ResultSet rs = DBExecuteSQL.executeQuery(sql);
        String returnValue = null;
        while (rs.next()) {
            returnValue = rs.getString("MiddleName");
        }
        return returnValue;
    }

    public static int getMaxYear() throws SQLException {
        String sql = "SELECT MAX(YearID) AS MaxYearID from Years;";
        ResultSet rs = DBExecuteSQL.executeQuery(sql);
        int returnValue = 0;
        while (rs.next()) {
            returnValue = rs.getInt("MaxYearID");
        }
        return returnValue;
    }

    public static void genYearsList() throws SQLException {
        Years.clearList();
        String sql = "SELECT * FROM Years ORDER BY YearID;";
        ResultSet rs = DBExecuteSQL.executeQuery(sql);
        while (rs.next()) {
            Years.addYearsList(new Years(
                    rs.getInt("YearID"),
                    rs.getString("TeamName")
            ));
        }
    }

    public static void genPlayersList() throws  SQLException {
        Players.clearList();
        String sql = "SELECT * FROM Players ORDER BY PlayerID;";
        ResultSet rs = DBExecuteSQL.executeQuery(sql);
        while (rs.next()) {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDate birthDay = LocalDate.parse(rs.getString("Birthday"), formatter);
            LocalDate now = LocalDate.now();
            Period age = Period.between(birthDay, now);
            Players.addPlayersList(new Players(
                    rs.getInt("PlayerID"),
                    rs.getString("FirstName"),
                    rs.getString("MiddleName"),
                    rs.getString("LastName"),
                    birthDay,
                    age.getYears()
            ));
        }
    }

    public static void genInjuryList(int yearID) throws SQLException {
        Injuries.clearList();
        String sql = "SELECT * FROM Injuries WHERE RosterID IN (SELECT RosterID FROM Rosters WHERE YearID=" + yearID + ") ORDER BY RosterID;";
        ResultSet rs = DBExecuteSQL.executeQuery(sql);
        while (rs.next()) {
            Injuries.addInjuryList(new Injuries(
                    rs.getInt("InjuryID"),
                    rs.getInt("RosterID"),
                    rs.getInt("JerseyNumber"),
                    rs.getString("FirstName"),
                    rs.getString("LastName"),
                    rs.getString("Position")
            ));
        }
    }

    public static void genDepthChartList(int yearID) throws SQLException {
        DepthCharts.clearList();
        String sql = "SELECT * FROM DepthCharts WHERE RosterID IN (SELECT RosterID FROM Rosters WHERE YearID=" + yearID + ") ORDER BY Position,String;";
        ResultSet rs = DBExecuteSQL.executeQuery(sql);
        while (rs.next()) {
            int playerID = rs.getInt("PlayerID");
            int rosterID = rs.getInt("RosterID");
            DepthCharts.addDepthChartList(new DepthCharts(
                    rs.getInt("DepthChartID"),
                    rs.getInt("RosterID"),
                    playerID,
                    rs.getString("Position"),
                    rs.getInt("String"),
                    DBRead.getFirstName(playerID),
                    DBRead.getLastName(playerID),
                    DBRead.getAgeForYear(Years.getYearsList().get(HomeController.yearIndex).getYearID(), playerID),
                    DBRead.getHeightFormatted(rosterID),
                    DBRead.getWeight(rosterID),
                    DBRead.getBench(rosterID),
                    DBRead.getSquat(rosterID),
                    DBRead.getFortyTime(rosterID),
                    DBRead.getPosition(rosterID),
                    DBRead.getJerseyNumber(rosterID)
            ));
        }
    }

    public static boolean checkYearExist(int yearID) throws SQLException {
        String sql = "SELECT YearID FROM Years WHERE YearID=" + yearID + ";";
        ResultSet rs = DBExecuteSQL.executeQuery(sql);
        return rs.next();
    }

    public static String getHeightFormatted(int rosterID) throws SQLException {
        String sql = "SELECT Height FROM Rosters WHERE rosterID=" + rosterID + ";";
        ResultSet rs = DBExecuteSQL.executeQuery(sql);
        String heightFeet = String.valueOf(abs((rs.getInt("Height"))) / 12);
        String heightInches = String.valueOf(abs((rs.getInt("Height"))) % 12);
        return heightFeet + "'" + heightInches;
    }

    public static int getHeight(int rosterID) throws SQLException {
        String sql = "SELECT Height FROM Rosters WHERE RosterID=" + rosterID + ";";
        ResultSet rs = DBExecuteSQL.executeQuery(sql);
        if (rs.getInt("Height") == 0) {
            return 72;
        } else {
            return rs.getInt("Height");
        }
    }

    public static int getJerseyNumber(int rosterID) throws SQLException {
        String sql = "SELECT JerseyNumber FROM Rosters WHERE RosterID=" + rosterID + ";";
        ResultSet rs = DBExecuteSQL.executeQuery(sql);
        return rs.getInt("JerseyNumber");
    }

    public static int getWeight(int rosterID) throws SQLException {
        String sql = "SELECT Weight FROM Rosters WHERE RosterID=" + rosterID + ";";
        ResultSet rs = DBExecuteSQL.executeQuery(sql);
        return rs.getInt("Weight");
    }

    public static int getBench(int rosterID) throws SQLException {
        String sql = "SELECT BenchPress FROM Rosters WHERE RosterID=" + rosterID + ";";
        ResultSet rs = DBExecuteSQL.executeQuery(sql);
        return rs.getInt("BenchPress");
    }

    public static int getSquat(int rosterID) throws SQLException {
        String sql = "SELECT Squat FROM Rosters WHERE RosterID=" + rosterID + ";";
        ResultSet rs = DBExecuteSQL.executeQuery(sql);
        return rs.getInt("Squat");
    }

    public static float getFortyTime(int rosterID) throws SQLException {
        String sql = "SELECT FortyTime FROM Rosters WHERE RosterID=" + rosterID + ";";
        ResultSet rs = DBExecuteSQL.executeQuery(sql);
        return rs.getFloat("FortyTime");
    }

    public static String getPosition(int rosterID) throws SQLException {
        String sql = "SELECT Position FROM Rosters WHERE RosterID=" + rosterID + ";";
        ResultSet rs = DBExecuteSQL.executeQuery(sql);
        return rs.getString("Position");
    }

    public static void genRostersList() throws SQLException {
        Rosters.clearList();
        String sql = "SELECT * FROM Rosters ORDER BY RosterID;";
        ResultSet rs = DBExecuteSQL.executeQuery(sql);
        while (rs.next()) {
            String heightFeet = String.valueOf((rs.getInt("Height")) / 12);
            String heightInches = String.valueOf((rs.getInt("Height")) % 12);
            String height = heightFeet + "'" + heightInches;
            int playerID = rs.getInt("PlayerID");
            Rosters.addRostersList(new Rosters(
                    rs.getInt("RosterID"),
                    rs.getInt("YearID"),
                    rs.getString("TeamName"),
                    playerID,
                    getFirstName(playerID),
                    getLastName(playerID),
                    rs.getInt("Age"),
                    rs.getInt("JerseyNumber"),
                    height,
                    rs.getInt("Weight"),
                    rs.getInt("BenchPress"),
                    rs.getInt("Squat"),
                    rs.getFloat("FortyTime"),
                    rs.getString("Position")
            ));
        }
    }

    public static String getFirstName(int playerID) throws SQLException {
        String sql = "SELECT FirstName FROM Players WHERE PlayerID=" + playerID + ";";
        ResultSet rs = DBExecuteSQL.executeQuery(sql);
        String returnValue = null;
        while (rs.next()) {
            returnValue = rs.getString("FirstName");
        }
        return returnValue;
    }

    public static String getLastName(int playerID) throws SQLException {
        String sql = "SELECT LastName FROM Players WHERE PlayerID=" + playerID + ";";
        ResultSet rs = DBExecuteSQL.executeQuery(sql);
        String returnValue = null;
        while (rs.next()) {
            returnValue = rs.getString("LastName");
        }
        return returnValue;
    }

    public static int getAgeForYear(int yearID, int playerID) throws SQLException {
        String sql = "SELECT Birthday FROM Players WHERE PlayerID=" + playerID + ";";
        ResultSet rs = DBExecuteSQL.executeQuery(sql);
        int returnValue = 0;
        while (rs.next()) {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDate birthDay = LocalDate.parse(rs.getString("Birthday"), formatter);
            LocalDate year = LocalDate.parse(yearID + "-08-01", formatter);
            Period age = Period.between(birthDay, year);
            returnValue = age.getYears();
        }
        return returnValue;
    }

    public static int getMaxStringByPosition(int yearID, String position) throws SQLException {
        String sql = "SELECT MAX(String) AS LastString FROM DepthCharts WHERE RosterID IN (SELECT RosterID FROM Rosters WHERE YearID=" + yearID + ") AND Position='" + position + "';";
        ResultSet rs = DBExecuteSQL.executeQuery(sql);
        return rs.getInt("LastString");
    }

    public static boolean loginCheck(String username, String password) throws SQLException {
        String sql = "SELECT * FROM Users";
        ResultSet rs = DBExecuteSQL.executeQuery(sql);
        while (rs.next()) {
            if (rs.getString("Username").equals(username) && rs.getString("Password").equals(password)) {
                return true;
            }
        }
        return false;
    }

}
