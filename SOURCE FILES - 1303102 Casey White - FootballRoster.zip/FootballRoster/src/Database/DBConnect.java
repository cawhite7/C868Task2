package Database;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnect {

    public static Connection conn = null;
    public static String homeDir = System.getProperty("user.home") + "\\FootballRoster";

    public static void connect() {
        // Checks or creates the FootballPath directory under the users home directory.
        try {
            File directory = new File(homeDir);
            if (!directory.exists()) directory.mkdirs();
            String url = "jdbc:sqlite:" + homeDir + "\\FootballRoster-main.db";
            conn = DriverManager.getConnection(url);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    // Closes db connection after application is closed by user
    public static void closeConnection() {
        try {
            if (conn != null) {
                conn.close();
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }


}
