package Database;

public class DBCreateTables {

    public static void createTables() {

        // Creates the Years table with both columns creating a composite primary key
        String sql = "CREATE TABLE Years" +
                "(YearID INTEGER NOT NULL," +
                "TeamName TEXT NOT NULL," +
                "PRIMARY KEY (YearID,TeamName));";
        DBExecuteSQL.execute(sql);

        // Creates the Players table with the first column being the primary key
        String sql2 = "CREATE TABLE Players" +
                "(PlayerID INTEGER PRIMARY KEY AUTOINCREMENT," +
                "FirstName TEXT," +
                "MiddleName TEXT," +
                "LastName TEXT," +
                "Birthday TEXT);";
        DBExecuteSQL.execute(sql2);

        /* Creates the Rosters table referencing YearID and TeamName to the Years Table
            As well as the PlayerID referencing the Players table
            ON DELETE CASCADE will delete the entire roster if the yearID is deleted
            ON UPDATE CASCADE will update the year if YearID is updated in the Years table
         */
        String sql3 = "CREATE TABLE Rosters" +
                "(RosterID INTEGER PRIMARY KEY AUTOINCREMENT," +
                "YearID INTEGER," +
                "TeamName TEXT," +
                "PlayerID INTEGER REFERENCES Players(PlayerID) ON DELETE CASCADE," +
                "Age INTEGER," +
                "JerseyNumber INTEGER," +
                "Height INTEGER," +
                "Weight INTEGER," +
                "BenchPress INTEGER," +
                "Squat INTEGER," +
                "FortyTime REAL," +
                "Position TEXT," +
                "FOREIGN KEY(YearID,TeamName) REFERENCES Years(YearID,TeamName) ON DELETE CASCADE ON UPDATE CASCADE);";
        DBExecuteSQL.execute(sql3);

        // Creates the DepthCharts table
        String sql4 = "CREATE TABLE DepthCharts" +
                "(DepthChartID INTEGER PRIMARY KEY AUTOINCREMENT," +
                "RosterID INTEGER REFERENCES Rosters(RosterID) ON DELETE CASCADE," +
                "PlayerID INTEGER REFERENCES Players(PlayerID) ON DELETE CASCADE," +
                "Position TEXT," +
                "String INTEGER);";
        DBExecuteSQL.execute(sql4);

        // Creates the Injuries Table
        String sql5 = "CREATE TABLE Injuries" +
                "(InjuryID INTEGER PRIMARY KEY AUTOINCREMENT," +
                "RosterID INTEGER REFERENCES Rosters(RosterID) ON DELETE CASCADE," +
                "JerseyNumber INTEGER," +
                "FirstName TEXT," +
                "LastName TEXT," +
                "Position TEXT);";
        DBExecuteSQL.execute(sql5);

        String sql6 = "CREATE TABLE Users" +
                "(Username TEXT PRIMARY KEY," +
                "Password TEXT);";
        DBExecuteSQL.execute(sql6);

        String sql7 = "INSERT INTO Users VALUES ('Admin','Password1');";
        DBExecuteSQL.execute(sql7);

    }

}
