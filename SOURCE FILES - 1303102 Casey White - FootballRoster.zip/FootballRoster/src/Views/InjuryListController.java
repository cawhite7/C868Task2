package Views;

import Database.DBCreate;
import Database.DBDelete;
import Database.DBRead;
import Main.Main;
import Structure.Injuries;
import Structure.Rosters;
import Structure.Years;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.TableView;

import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class InjuryListController implements Initializable {
    public TableView<Injuries> IRTable;
    public TableView<Rosters> rosterTable;
    private Injuries selectedInjury;
    private Rosters selectedRoster;

    public boolean checkPlayerExists() {
        for (Injuries player : Injuries.getInjuryList()) {
            if (selectedRoster.getRosterID() == player.getRosterID()) {
                return true;
            }
        }
        return false;
    }

    public void addButtonClick() throws SQLException {
        if (selectedRoster != null) {
            if (!checkPlayerExists()) {
                DBCreate.addPlayerToInjury(
                        selectedRoster.getRosterID(),
                        selectedRoster.getJerseyNumber(),
                        selectedRoster.getFirstName(),
                        selectedRoster.getLastName(),
                        selectedRoster.getPosition()
                );
                DBRead.genInjuryList(Years.getYearsList().get(HomeController.yearIndex).getYearID());
                IRTable.setItems(Injuries.getInjuryList());
            } else {
                Alert alter = new Alert(Alert.AlertType.WARNING);
                alter.setHeaderText("Player Exists");
                alter.setContentText("Player already exists in the injury list");
                alter.show();
            }
        } else {
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Select Player");
            alter.setContentText("Please select a player from the roster to add");
            alter.show();
        }
    }

    public void removeButtonClick() throws SQLException {
        if (selectedInjury != null) {
            DBDelete.deletePlayerFromInjuries(selectedInjury.getInjuryID());
            DBRead.genInjuryList(Years.getYearsList().get(HomeController.yearIndex).getYearID());
            IRTable.setItems(Injuries.getInjuryList());
        } else {
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Select Player");
            alter.setContentText("Please select a player from the injured list to remove");
            alter.show();
        }
    }

    public void closeButtonClick() {
        HomeController.injuryListStage.close();
        Main.homeStage.show();
    }

    public void IRTableClick() {
        selectedInjury = IRTable.getSelectionModel().getSelectedItem();
    }

    public void rosterTable() {
        selectedRoster = rosterTable.getSelectionModel().getSelectedItem();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
            DBRead.genInjuryList(Years.getYearsList().get(HomeController.yearIndex).getYearID());
        } catch (SQLException e) {
            e.printStackTrace();
        }
        IRTable.setItems(Injuries.getInjuryList());
        rosterTable.setItems(Rosters.getRostersListByYear(Years.getYearsList().get(HomeController.yearIndex).getYearID()));
    }
}
