package Views;

import Database.DBCreate;
import Database.DBDelete;
import Database.DBRead;
import Main.Main;
import Structure.Players;
import Structure.Years;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableView;
import javafx.scene.image.Image;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class AddPlayerController implements Initializable {

    public TableView<Players> playersTable;
    public static Players selectedPlayer;
    public static ObservableList<Players> selectedPlayers = FXCollections.observableArrayList();
    public static Stage newPlayerStage = new Stage();
    public static Stage modifyPlayerStage = new Stage();

    public void addToRosterButtonClick() throws SQLException {
        if (selectedPlayer != null) {
            selectedPlayers = playersTable.getSelectionModel().getSelectedItems();
            if (Years.getYearsList().size() != 0 && selectedPlayers.isEmpty()) {
                DBCreate.addPlayerToRoster(Years.getYearsList().get(HomeController.yearIndex).getYearID(), selectedPlayer.getPlayerID(), DBRead.getAgeForYear(Years.getYearsList().get(HomeController.yearIndex).getYearID(), selectedPlayer.getPlayerID()));
                HomeController.addPlayerStage.close();
                Main.homeStage.show();
            } else if (Years.getYearsList().size() != 0) {
                for (Players player : selectedPlayers) {
                    DBCreate.addPlayerToRoster(Years.getYearsList().get(HomeController.yearIndex).getYearID(), player.getPlayerID(), DBRead.getAgeForYear(Years.getYearsList().get(HomeController.yearIndex).getYearID(), player.getPlayerID()));
                }
                HomeController.addPlayerStage.close();
                Main.homeStage.show();
            } else {
                Alert alter = new Alert(Alert.AlertType.WARNING);
                alter.setHeaderText("No Data");
                alter.setContentText("No year for roster data to add to");
                alter.show();
            }
        } else {
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("No Player Selected");
            alter.setContentText("Please select player/s to add");
            alter.show();
        }
        selectedPlayers = null;
        selectedPlayer = null;
    }

    public void cancelButtonClick() {
        selectedPlayers = null;
        selectedPlayer = null;
        HomeController.addPlayerStage.close();
        Main.homeStage.show();
    }

    public void playerTableClick() {
        selectedPlayer = playersTable.getSelectionModel().getSelectedItem();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        HomeController.addPlayerStage.setOnShowing(windowEvent -> {
            try {
                DBRead.genPlayersList();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            playersTable.setItems(Players.getPlayersList());
        });
        playersTable.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
    }

    public void newPlayerButtonClick() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("NewPlayer.fxml"));
        newPlayerStage.getIcons().add(new Image(this.getClass().getResourceAsStream("white.png")));
        newPlayerStage.setScene(new Scene(root, 700, 400));
        HomeController.addPlayerStage.hide();
        newPlayerStage.show();
    }

    public void modifyPlayerButtonClick() throws IOException {
        if (selectedPlayer != null) {
            Parent root = FXMLLoader.load(getClass().getResource("ModifyPlayer.fxml"));
            modifyPlayerStage.getIcons().add(new Image(this.getClass().getResourceAsStream("white.png")));
            modifyPlayerStage.setScene(new Scene(root, 700, 400));
            HomeController.addPlayerStage.hide();
            modifyPlayerStage.show();
        } else {
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Select Player");
            alter.setContentText("Please select a player to modify");
            alter.show();
        }
    }

    public void deletePlayerButtonClick() {
        if (selectedPlayer != null) {
            try {
                DBDelete.deletePlayer(selectedPlayer.getPlayerID());
                DBRead.genPlayersList();
                DBRead.genRostersList();
                playersTable.setItems(Players.getPlayersList());
                selectedPlayer = null;
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else {
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Select Player");
            alter.setContentText("Please select a player to delete");
            alter.show();
        }
    }
}
