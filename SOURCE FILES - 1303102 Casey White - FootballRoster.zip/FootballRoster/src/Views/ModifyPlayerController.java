package Views;

import Database.DBUpdate;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;

import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class ModifyPlayerController implements Initializable {

    public DatePicker birthday;
    public TextField firstNameTF;
    public TextField middleNameTF;
    public TextField lastNameTF;

    private boolean checkNulls() {
        return !firstNameTF.getText().isBlank() && !lastNameTF.getText().isBlank() && birthday.getValue() != null;
    }

    public void submitButtonClick() {
        if (checkNulls()) {
            DBUpdate.updatePlayer(AddPlayerController.selectedPlayer.getPlayerID(), firstNameTF.getText(), middleNameTF.getText(), lastNameTF.getText(), birthday.getValue());
            try {
                DBUpdate.updateRosterAge(AddPlayerController.selectedPlayer.getPlayerID(), birthday.getValue());
            } catch (SQLException e) {
                e.printStackTrace();
            }
            AddPlayerController.modifyPlayerStage.close();
            HomeController.addPlayerStage.show();
        } else {
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Nulls");
            alter.setContentText("Only the middle name can be blank");
            alter.show();
        }
    }

    public void cancelButtonClick() {
        AddPlayerController.modifyPlayerStage.close();
        HomeController.addPlayerStage.show();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        firstNameTF.setText(AddPlayerController.selectedPlayer.getFirstName());
        middleNameTF.setText(AddPlayerController.selectedPlayer.getMiddleName());
        lastNameTF.setText(AddPlayerController.selectedPlayer.getLastName());
        birthday.setValue(AddPlayerController.selectedPlayer.getBirthDay());
    }

    public void firstNameTFType(KeyEvent keyEvent) {
        if (!keyEvent.getCharacter().matches("[a-zA-Z .\b\t]")) {
            if (firstNameTF.getText().length() == 1) firstNameTF.clear();
            else {
                firstNameTF.setText(firstNameTF.getText().substring(0, firstNameTF.getText().length() - 1));
                firstNameTF.positionCaret(firstNameTF.getText().length());
            }
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Letters only");
            alter.setContentText("Please only input letters");
            alter.show();
        }
        if (firstNameTF.getText().length() > 15) {
            firstNameTF.setText(firstNameTF.getText().substring(0, 15));
            firstNameTF.positionCaret(firstNameTF.getText().length());
        }
    }

    public void middleNameType(KeyEvent keyEvent) {
        if (!keyEvent.getCharacter().matches("[a-zA-Z .\b\t]")) {
            if (middleNameTF.getText().length() == 1) middleNameTF.clear();
            else {
                middleNameTF.setText(middleNameTF.getText().substring(0, middleNameTF.getText().length() - 1));
                middleNameTF.positionCaret(middleNameTF.getText().length());
            }
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Letters only");
            alter.setContentText("Please only input letters");
            alter.show();
        }
        if (middleNameTF.getText().length() > 15) {
            middleNameTF.setText(middleNameTF.getText().substring(0, 15));
            middleNameTF.positionCaret(middleNameTF.getText().length());
        }
    }

    public void lastNameType(KeyEvent keyEvent) {
        if (!keyEvent.getCharacter().matches("[a-zA-Z .\b\t]")) {
            if (lastNameTF.getText().length() == 1) lastNameTF.clear();
            else {
                lastNameTF.setText(lastNameTF.getText().substring(0, lastNameTF.getText().length() - 1));
                lastNameTF.positionCaret(lastNameTF.getText().length());
            }
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Letters only");
            alter.setContentText("Please only input letters");
            alter.show();
        }
        if (lastNameTF.getText().length() > 15) {
            lastNameTF.setText(lastNameTF.getText().substring(0, 15));
            lastNameTF.positionCaret(lastNameTF.getText().length());
        }
    }
}
