package Views;

import Database.DBCreate;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;

import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class NewPlayerController implements Initializable {

    public TextField firstNameTF;
    public TextField middleNameTF;
    public TextField lastNameTF;
    public DatePicker birthday;

    private boolean checkNulls() {
        return !firstNameTF.getText().isBlank() && !lastNameTF.getText().isBlank() && birthday.getValue() != null;
    }

    public void submitButtonClick() {
        if (checkNulls()) {
            assert firstNameTF != null;
            DBCreate.newPlayer(firstNameTF.getText(), middleNameTF.getText(), lastNameTF.getText(), String.valueOf(birthday.getValue()));
            AddPlayerController.newPlayerStage.close();
            HomeController.addPlayerStage.show();
        } else {
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Nulls");
            alter.setContentText("Only the middle name can be blank");
            alter.show();
        }
    }

    public void cancelButtonClick() {
        AddPlayerController.newPlayerStage.close();
        HomeController.addPlayerStage.show();
    }

    public void firstNameType(KeyEvent keyEvent) {
        if (!keyEvent.getCharacter().matches("[a-zA-Z .\b\t]")) {
            if (firstNameTF.getText().length() == 1) firstNameTF.clear();
            else {
                firstNameTF.setText(firstNameTF.getText().substring(0, firstNameTF.getText().length() - 1));
                firstNameTF.positionCaret(firstNameTF.getText().length());
            }
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Letters only");
            alter.setContentText("Please only input letters");
            alter.show();
        }
        if (firstNameTF.getText().length() > 15) {
            firstNameTF.setText(firstNameTF.getText().substring(0, 15));
            firstNameTF.positionCaret(firstNameTF.getText().length());
        }
    }

    public void middleNameType(KeyEvent keyEvent) {
        if (!keyEvent.getCharacter().matches("[a-zA-Z .\b\t]")) {
            if (middleNameTF.getText().length() == 1) middleNameTF.clear();
            else {
                middleNameTF.setText(middleNameTF.getText().substring(0, middleNameTF.getText().length() - 1));
                middleNameTF.positionCaret(middleNameTF.getText().length());
            }
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Letters only");
            alter.setContentText("Please only input letters");
            alter.show();
        }
        if (middleNameTF.getText().length() > 15) {
            middleNameTF.setText(middleNameTF.getText().substring(0, 15));
            middleNameTF.positionCaret(middleNameTF.getText().length());
        }
    }

    public void lastNameType(KeyEvent keyEvent) {
        if (!keyEvent.getCharacter().matches("[a-zA-Z .\b\t]")) {
            if (lastNameTF.getText().length() == 1) lastNameTF.clear();
            else {
                lastNameTF.setText(lastNameTF.getText().substring(0, lastNameTF.getText().length() - 1));
                lastNameTF.positionCaret(lastNameTF.getText().length());
            }
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Letters only");
            alter.setContentText("Please only input letters");
            alter.show();
        }
        if (lastNameTF.getText().length() > 15) {
            lastNameTF.setText(lastNameTF.getText().substring(0, 15));
            lastNameTF.positionCaret(lastNameTF.getText().length());
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        birthday.setValue(LocalDate.of(2000, 1, 1));
    }
}
