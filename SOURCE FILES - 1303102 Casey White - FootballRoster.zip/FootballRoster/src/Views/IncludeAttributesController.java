package Views;

import Database.DBRead;
import Structure.DepthCharts;
import Structure.Injuries;
import Structure.Years;
import javafx.scene.control.CheckBox;
import javafx.stage.FileChooser;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.sql.SQLException;
import java.util.ArrayList;

public class IncludeAttributesController {
    public CheckBox string;
    public CheckBox jerseyNumber;
    public CheckBox firstName;
    public CheckBox middleName;
    public CheckBox lastName;
    public CheckBox age;
    public CheckBox height;
    public CheckBox weight;
    public CheckBox bench;
    public CheckBox squat;
    public CheckBox fortyTime;
    public CheckBox position;
    private final ArrayList<CheckBox> listCheckBox = new ArrayList<>();
    ArrayList<String> headerList = new ArrayList<>();

    public void submitButtonClick() throws IOException, SQLException {

        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Export Depth Chart");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("CSV File", "*.csv")
        );
        File saveFile = fileChooser.showSaveDialog(DepthChartController.includeAttributesStage);

        File file = new File(saveFile.getCanonicalFile().getCanonicalPath());
        Files.deleteIfExists(file.toPath());
        //FileWriter writer = new FileWriter("Export.txt");
        FileWriter writer = new FileWriter(saveFile.getCanonicalFile().getCanonicalPath());

        genList();

        for (CheckBox checkBox : listCheckBox) {
            if (checkBox.isSelected()) headerList.add(checkBox.getId().substring(0,1).toUpperCase() + checkBox.getId().substring(1));
        }

        for (String position : DepthChartController.getPositionArray()) {
            writer.write(position +
                    "                                                                      " +
                    "                                                                      " +
                    "                                                                      " +
                    "                                \n");
            int count = 1;
            for (String header : headerList) {
                writer.write(header);
                if (count < headerList.size()) writer.write(",");
                count++;
            }
            writer.write("\n");
            for (DepthCharts player : DepthCharts.getDepthChartList()) {
                if (player.getPositionL().equals(position)) {
                    for (String header : headerList) {
                        if (header.equals("String")) writer.write(player.getString() + ",");
                        if (header.equals("JerseyNumber")) writer.write(player.getJerseyNumber() + ",");
                        if (header.equals("FirstName")) writer.write(player.getFirstName() + ",");
                        if (header.equals("MiddleName")) writer.write(DBRead.getMiddleName(player.getPlayerID()) + ",");
                        if (header.equals("LastName")) writer.write(player.getLastName() + ",");
                        if (header.equals("Age")) writer.write(player.getAge() + ",");
                        if (header.equals("Height")) writer.write(player.getHeight() + ",");
                        if (header.equals("Weight")) writer.write(player.getWeight() + ",");
                        if (header.equals("Bench")) writer.write(player.getBench() + ",");
                        if (header.equals("Squat")) writer.write(player.getSquat() + ",");
                        if (header.equals("FortyTime")) writer.write(player.getFortyTime() + ",");
                        if (header.equals("Position")) writer.write(player.getPosition() + ",");
                    }
                    writer.write("\n");
                }
            }
            writer.write("\n");
        }

        writer.write("Injury List                                                        \n");

        String[] header2 = { "Jersey Number", "First Name", "Last Name", "Position" };
        int count = 1;
        for (String header : header2) {
            writer.write(header);
            if (count < headerList.size()) writer.write(",");
            count++;
        }

        writer.write("\n");

        DBRead.genInjuryList(Years.getYearsList().get(HomeController.yearIndex).getYearID());
        for (Injuries player : Injuries.getInjuryList()) {
            writer.write(player.getJerseyNumber() + ",");
            writer.write(player.getFirstName() + ",");
            writer.write(player.getLastName() + ",");
            writer.write(player.getPosition() + "\n");
        }

        /*
        writer.write("O-Line Average Weight" + "\n");
        int sum = 0;
        for (DepthCharts player : DepthCharts.getStartingOffenseLine()) {
            sum += player.getWeight();
        }
        writer.write(String.valueOf(sum / DepthCharts.getStartingOffenseLine().size()));
        writer.write("\n");
         */

        writer.flush();
        writer.close();

        DepthChartController.includeAttributesStage.close();
        HomeController.depthChartStage.show();
    }



    private void genList() {
        listCheckBox.add(string); listCheckBox.add(jerseyNumber); listCheckBox.add(firstName);
        listCheckBox.add(middleName); listCheckBox.add(lastName); listCheckBox.add(age);
        listCheckBox.add(height); listCheckBox.add(weight); listCheckBox.add(bench);
        listCheckBox.add(squat); listCheckBox.add(fortyTime); listCheckBox.add(position);
    }

}
