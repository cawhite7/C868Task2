package Views;

import Database.DBCreate;
import Database.DBDelete;
import Database.DBRead;
import Database.DBUpdate;
import Main.Main;
import Structure.DepthCharts;
import Structure.Rosters;
import Structure.Years;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.image.Image;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.ResourceBundle;

public class DepthChartController implements Initializable {

    public Label yearLabel;
    public TableView<String> stringTable;
    public TableColumn<String, String> stringColumn;
    public Label positionLabel;
    public TableView<Rosters> rosterTable;
    public TableView<DepthCharts> depthChartTable;
    private int positionsIndex = 0;
    private final ObservableList<String> stringsList = FXCollections.observableArrayList();
    private Rosters selectedSubRosterPlayer;
    private DepthCharts selectedDPPlayer;
    int size = 0;
    public static Stage includeAttributesStage = new Stage();
    String[] strings = { "First", "Second", "Third", "Fourth", "Fifth", "Sixth", "Seventh" };
    private static final String[] positions = {
            Rosters.Position.OffensePosition.QB,
            Rosters.Position.OffensePosition.WR,
            Rosters.Position.OffensePosition.TE,
            Rosters.Position.OffensePosition.RB,
            Rosters.Position.OffensePosition.FB,
            Rosters.Position.OffensePosition.LT,
            Rosters.Position.OffensePosition.LG,
            Rosters.Position.OffensePosition.C,
            Rosters.Position.OffensePosition.RG,
            Rosters.Position.OffensePosition.RT,
            Rosters.Position.DefensePosition.NOSE,
            Rosters.Position.DefensePosition.DT,
            Rosters.Position.DefensePosition.DE,
            Rosters.Position.DefensePosition.OLB,
            Rosters.Position.DefensePosition.MLB,
            Rosters.Position.DefensePosition.CB,
            Rosters.Position.DefensePosition.FS,
            Rosters.Position.DefensePosition.SS,
            Rosters.Position.SpecialTeamPosition.K,
            Rosters.Position.SpecialTeamPosition.P,
            Rosters.Position.SpecialTeamPosition.H,
            Rosters.Position.SpecialTeamPosition.LS,
            Rosters.Position.SpecialTeamPosition.PR,
            Rosters.Position.SpecialTeamPosition.KR
    };

    public static String[] getPositionArray() {
        return positions;
    }

    public void closeButtonClick() {
        HomeController.depthChartStage.close();
        Main.homeStage.show();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
            DBRead.genDepthChartList(Years.getYearsList().get(HomeController.yearIndex).getYearID());
            DepthCharts.genDepthChartByPosition();
            depthChartTable.setItems(DepthCharts.getPositionList(positions[positionsIndex]));
        } catch (SQLException e) {
            e.printStackTrace();
        }
        rosterTable.setItems(Rosters.getRostersListByYear(Years.getYearsList().get(HomeController.yearIndex).getYearID()));
        yearLabel.setText(String.valueOf(Years.getYearsList().get(HomeController.yearIndex).getYearID()));
        positionLabel.setText(positions[0]);
        stringsList.addAll(Arrays.asList(strings).subList(0, size));
        stringColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue()));
        genStringsTable();
    }

    public void rosterTableClick() {
        selectedSubRosterPlayer = rosterTable.getSelectionModel().getSelectedItem();
    }

    public void addButtonClick() throws SQLException {
        if (selectedSubRosterPlayer != null) {
            if (!checkDPPlayerExists(positions[positionsIndex], selectedSubRosterPlayer.getRosterID())) {
                DBCreate.addPlayerToDepthChart(
                        selectedSubRosterPlayer.getRosterID(),
                        selectedSubRosterPlayer.getPlayerID(),
                        positions[positionsIndex],
                        DepthCharts.getPositionList(positions[positionsIndex]).size() + 1
                );
                DBRead.genDepthChartList(Years.getYearsList().get(HomeController.yearIndex).getYearID());
                DepthCharts.genDepthChartByPosition();
                depthChartTable.setItems(DepthCharts.getPositionList(positions[positionsIndex]));
                genStringsTable();
            }
        } else {
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Select Player");
            alter.setContentText("Please select a player from the roster to add");
            alter.show();
        }
    }

    public boolean checkDPPlayerExists(String position, int rosterID) {
        for (int i = 0; i < 10; i++) {
            if (positions[i].equals(position)) {
                for (int j = 0; j < 10; j++) {
                    for (DepthCharts player : DepthCharts.getPositionList(positions[j])) {
                        if (player.getRosterID() == rosterID) {
                            Alert alter = new Alert(Alert.AlertType.WARNING);
                            alter.setHeaderText("Player already exists");
                            alter.setContentText("Player is already on Offense as a (" + player.getPositionL() + ")");
                            alter.show();
                            return true;
                        }
                    }
                }
            }
        }
        for (int i = 10; i < 18; i++) {
            if (positions[i].equals(position)) {
                for (int j = 10; j < 18; j++) {
                    for (DepthCharts player : DepthCharts.getPositionList(positions[j])) {
                        if (player.getRosterID() == rosterID) {
                            Alert alter = new Alert(Alert.AlertType.WARNING);
                            alter.setHeaderText("Player already exists");
                            alter.setContentText("Player is already on Defense as a (" + player.getPositionL() + ")");
                            alter.show();
                            return true;
                        }
                    }
                }
            }
        }
        for (int i = 18; i < 24; i++) {
            if (positions[i].equals(position)) {
                for (int j = 18; j < 24; j++) {
                    for (DepthCharts player : DepthCharts.getPositionList(positions[j])) {
                        if (player.getRosterID() == rosterID) {
                            Alert alter = new Alert(Alert.AlertType.WARNING);
                            alter.setHeaderText("Player already exists");
                            alter.setContentText("Player is already on Special Teams as a (" + player.getPositionL() + ")");
                            alter.show();
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    public void removeButtonClick() throws SQLException {
        if (selectedDPPlayer != null) {
            DBUpdate.changeStrings(selectedDPPlayer);
            DBDelete.deletePlayerFromDepthChart(selectedDPPlayer.getDepthChartID());
            DBRead.genDepthChartList(Years.getYearsList().get(HomeController.yearIndex).getYearID());
            DepthCharts.genDepthChartByPosition();
            depthChartTable.setItems(DepthCharts.getPositionList(positions[positionsIndex]));
            genStringsTable();
        } else {
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Select Player");
            alter.setContentText("Please select a player from the depth chart to remove");
            alter.show();
        }
    }

    public void depthChartTableClick() {
        selectedDPPlayer = depthChartTable.getSelectionModel().getSelectedItem();
    }

    public void previousButtonClick() {
        if (positionsIndex != 0) {
            positionLabel.setText(positions[--positionsIndex]);
            //DBRead.genDepthChartList();
        } else {
            positionsIndex = positions.length - 1;
            positionLabel.setText(positions[positionsIndex]);
        }
        depthChartTable.setItems(DepthCharts.getPositionList(positions[positionsIndex]));
        genStringsTable();
        selectedDPPlayer = null;
    }

    public void nextButtonClick() {
        if (positionsIndex < positions.length - 1) {
            positionLabel.setText(positions[++positionsIndex]);
            //DBRead.genDepthChartList();
        } else {
            positionsIndex = 0;
            positionLabel.setText(positions[positionsIndex]);
        }
        depthChartTable.setItems(DepthCharts.getPositionList(positions[positionsIndex]));
        genStringsTable();
        selectedDPPlayer = null;
    }

    public void genStringsTable() {
        stringTable.getItems().clear();
        size = DepthCharts.getPositionList(positions[positionsIndex]).size();
        stringsList.addAll(Arrays.asList(strings).subList(0, size));
        stringTable.setItems(stringsList);
    }


    public void exportExcelButtonClick() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("IncludeAttributes.fxml"));
        includeAttributesStage.getIcons().add(new Image(this.getClass().getResourceAsStream("white.png")));
        includeAttributesStage.setScene(new Scene(root, 200, 400));
        HomeController.depthChartStage.hide();
        includeAttributesStage.show();
    }

    public void increaseStringButtonClick() throws SQLException {
        if (selectedDPPlayer != null && selectedDPPlayer.getString() != 1) {
            DBUpdate.upString(selectedDPPlayer);
            DBRead.genDepthChartList(Years.getYearsList().get(HomeController.yearIndex).getYearID());
            DepthCharts.genDepthChartByPosition();
            depthChartTable.setItems(DepthCharts.getPositionList(positions[positionsIndex]));
            genStringsTable();
        }
    }

    public void decreaseStringButtonClick() throws SQLException {
        if (selectedDPPlayer != null
                && selectedDPPlayer.getString() != DBRead.getMaxStringByPosition(Years.getYearsList().get(HomeController.yearIndex).getYearID(), selectedDPPlayer.getPositionL())) {
            DBUpdate.downString(selectedDPPlayer);
            DBRead.genDepthChartList(Years.getYearsList().get(HomeController.yearIndex).getYearID());
            DepthCharts.genDepthChartByPosition();
            depthChartTable.setItems(DepthCharts.getPositionList(positions[positionsIndex]));
            genStringsTable();
        }
    }
}
