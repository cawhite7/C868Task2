package Views;

import Database.DBRead;
import Main.Main;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;

import java.sql.SQLException;

public class LoginController {
    public TextField usernameTF;
    public TextField passwordTF;

    public boolean checkNulls() {
        return !usernameTF.getText().isBlank() && !passwordTF.getText().isBlank();
    }

    public void loginButtonClick() throws SQLException {
        if (checkNulls()) {
            if (DBRead.loginCheck(usernameTF.getText(), passwordTF.getText())) {
                Main.loginStage.close();
                Main.homeStage.show();
            } else {
                Alert alter = new Alert(Alert.AlertType.WARNING);
                alter.setHeaderText("Incorrect Credentials");
                alter.setContentText("Either username or password is incorrect");
                alter.show();
            }
        } else {
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Nulls");
            alter.setContentText("Please fill in both fields");
            alter.show();
        }
    }

    public void cancelButtonClick() {
        Main.loginStage.close();
    }

    public void usernameType(KeyEvent keyEvent) {
        if (!keyEvent.getCharacter().matches("[a-zA-Z0-9.\b\t]")) {
            if (usernameTF.getText().length() == 1) usernameTF.clear();
            else {
                usernameTF.setText(usernameTF.getText().substring(0, usernameTF.getText().length() - 1));
                usernameTF.positionCaret(usernameTF.getText().length());
            }
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Letters only");
            alter.setContentText("Please only input letters, numbers, or periods");
            alter.show();
        }
        if (usernameTF.getText().length() > 15) {
            usernameTF.setText(usernameTF.getText().substring(0, 15));
            usernameTF.positionCaret(usernameTF.getText().length());
        }
    }

    public void passwordType(KeyEvent keyEvent) {
        if (!keyEvent.getCharacter().matches("[a-zA-Z0-9.&%\b\t]")) {
            if (passwordTF.getText().length() == 1) passwordTF.clear();
            else {
                passwordTF.setText(passwordTF.getText().substring(0, passwordTF.getText().length() - 1));
                passwordTF.positionCaret(passwordTF.getText().length());
            }
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Letters only");
            alter.setContentText("Please only input letters, numbers, &, %, or periods");
            alter.show();
        }
        if (passwordTF.getText().length() > 15) {
            passwordTF.setText(passwordTF.getText().substring(0, 15));
            passwordTF.positionCaret(passwordTF.getText().length());
        }
    }
}
