package Views;

import Database.*;
import Main.Main;
import Structure.Rosters;
import Structure.Years;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.sql.SQLException;
import java.util.Optional;
import java.util.ResourceBundle;

import static Structure.Years.getYearsList;

public class HomeController implements Initializable {

    public Label yearLabel;
    public TextField teamNameLabel;
    public static int yearIndex = 0;
    public TableView<Rosters> rosterTable;

    public static Stage addPlayerStage = new Stage();
    public static Stage modifyPlayerStage = new Stage();
    public static Stage depthChartStage = new Stage();
    public static Stage addYearStage = new Stage();
    public static Stage injuryListStage = new Stage();
    public static Stage changePasswordStage = new Stage();

    public static Rosters selectedPlayer;
    public Button confirmButton;
    public Button prevButton;
    public Button nextButton;
    public Button confirmButton1;
    public Button searchButton;
    public TextField searchField;
    private int switcher = 0;
    private int switcher2 = 0;

    public void prevButtonClick() {
        if (Years.getYearsList().size() != 0 && yearIndex > 0) {
            yearIndex--;
            yearLabel.setText(String.valueOf(getYearsList().get(yearIndex).getYearID()));
            try {
                teamNameLabel.setText(DBRead.getTeamName(getYearsList().get(yearIndex).getYearID()));
            } catch (SQLException e) {
                e.printStackTrace();
            }
            rosterTable.setItems(Rosters.getRostersListByYear(getYearsList().get(yearIndex).getYearID()));
        }
    }

    public void nextButtonClick() throws SQLException {
        if (Years.getYearsList().size() != 0 && getYearsList().get(yearIndex).getYearID() < DBRead.getMaxYear()) {
            //yearLabel.setText(String.valueOf(++year));
            yearIndex++;
            yearLabel.setText(String.valueOf(getYearsList().get(yearIndex).getYearID()));
            try {
                teamNameLabel.setText(DBRead.getTeamName(getYearsList().get(yearIndex).getYearID()));
            } catch (SQLException e) {
                e.printStackTrace();
            }
            rosterTable.setItems(Rosters.getRostersListByYear(getYearsList().get(yearIndex).getYearID()));
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
            DBRead.genYearsList();
            DBRead.genRostersList();
            DBRead.genPlayersList();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        if (Years.getYearsList().size() != 0) {
            yearLabel.setText(String.valueOf(getYearsList().get(yearIndex).getYearID()));
            rosterTable.setItems(Rosters.getRostersListByYear(getYearsList().get(0).getYearID()));
        } else {
            yearLabel.setText("Year");
        }

        if (Years.getYearsList().size() != 0) {
            try {
                teamNameLabel.setText(DBRead.getTeamName(Years.getYearsList().get(HomeController.yearIndex).getYearID()));
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else {
            teamNameLabel.setText("Team Name");
        }

        Main.homeStage.setOnShown(windowEvent -> refreshInit());
    }

    public void closeButtonClick() {
        Main.homeStage.close();
    }

    public void addPlayerButtonClick() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("AddPlayer.fxml"));
        addPlayerStage.getIcons().add(new Image(this.getClass().getResourceAsStream("white.png")));
        addPlayerStage.setScene(new Scene(root, 700, 400));
        Main.homeStage.hide();
        addPlayerStage.show();
    }

    public void modifyPlayerButtonClick() throws IOException {
        if (selectedPlayer != null) {
            Parent root = FXMLLoader.load(getClass().getResource("ModifyRosterPlayer.fxml"));
            modifyPlayerStage.getIcons().add(new Image(this.getClass().getResourceAsStream("white.png")));
            modifyPlayerStage.setScene(new Scene(root, 400, 600));
            Main.homeStage.hide();
            modifyPlayerStage.show();
        } else {
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Select Player");
            alter.setContentText("Please select a player to modify");
            alter.show();
        }
    }

    public void deletePlayerButtonClick() {
        if (selectedPlayer != null) {
            try {
                DBDelete.deletePlayerFromRoster(selectedPlayer.getRosterID(),selectedPlayer.getPlayerID());
                DBRead.genRostersList();
                rosterTable.setItems(Rosters.getRostersListByYear(Years.getYearsList().get(HomeController.yearIndex).getYearID()));
                selectedPlayer = null;
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else {
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Select Player");
            alter.setContentText("Please select a player to delete");
            alter.show();
        }
    }

    public void rosterTableClick() {
        selectedPlayer = rosterTable.getSelectionModel().getSelectedItem();
    }

    public void teamNameLabelPress() {
        DBUpdate.updateTeamName(teamNameLabel.getText(), Years.getYearsList().get(HomeController.yearIndex).getYearID());
    }

    public void depthChartButtonClick() throws IOException {
        if (Years.getYearsList().size() != 0) {
            Parent root = FXMLLoader.load(getClass().getResource("DepthChart.fxml"));
            depthChartStage.getIcons().add(new Image(this.getClass().getResourceAsStream("white.png")));
            depthChartStage.setScene(new Scene(root, 1000, 700));
            Main.homeStage.hide();
            depthChartStage.show();
        } else {
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("No Data");
            alter.setContentText("No data to work off of");
            alter.show();
        }
    }

    public void addYearButtonClick() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("AddYear.fxml"));
        addYearStage.getIcons().add(new Image(this.getClass().getResourceAsStream("white.png")));
        addYearStage.setScene(new Scene(root, 300, 200));
        Main.homeStage.hide();
        addYearStage.show();
    }

    public void clearRosterButtonClick() {
        if ((Years.getYearsList().size() != 0)) {
            if (switcher2 == 0) {
                confirmButton1.setVisible(true);
                switcher2++;
            } else {
                confirmButton1.setVisible(false);
                switcher2--;
            }
        } else {
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("No Data");
            alter.setContentText("No data to clear");
            alter.show();
        }
    }

    public void confirmButtonClick1() throws SQLException {
        DBDelete.deleteRoster(getYearsList().get(yearIndex).getYearID());
        confirmButton1.setVisible(false);
        Rosters.clearList();
        DBRead.genRostersList();
        rosterTable.setItems(Rosters.getRostersListByYear(getYearsList().get(yearIndex).getYearID()));
        switcher2--;
    }

    public void deleteYearButtonClick() {
        if (Years.getYearsList().size() != 0) {
            if (switcher == 0) {
                confirmButton.setVisible(true);
                switcher++;
            } else {
                confirmButton.setVisible(false);
                switcher--;
            }
        } else {
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("No Data");
            alter.setContentText("No year available to delete");
            alter.show();
        }
    }

    public void confirmButtonClick() throws SQLException {
        DBDelete.deleteYear(Years.getYearsList().get(yearIndex).getYearID());
        DBRead.genYearsList();
        if (yearIndex > 0) {
            yearIndex--;
            yearLabel.setText(String.valueOf(getYearsList().get(yearIndex).getYearID()));
            try {
                teamNameLabel.setText(DBRead.getTeamName(getYearsList().get(yearIndex).getYearID()));
            } catch (SQLException e) {
                e.printStackTrace();
            }
            rosterTable.setItems(Rosters.getRostersListByYear(getYearsList().get(yearIndex).getYearID()));
        } else if (yearIndex == 0 && Years.getYearsList().size() > 0) {
            nextButton.fire();
            yearLabel.setText(String.valueOf(getYearsList().get(yearIndex).getYearID()));
            try {
                teamNameLabel.setText(DBRead.getTeamName(getYearsList().get(yearIndex).getYearID()));
            } catch (SQLException e) {
                e.printStackTrace();
            }
            rosterTable.setItems(Rosters.getRostersListByYear(getYearsList().get(yearIndex).getYearID()));
        } else {
            yearLabel.setText("Year");
            teamNameLabel.setText("Team Name");
            rosterTable.getItems().clear();
        }
        confirmButton.setVisible(false);
        switcher--;
        DBRead.genYearsList();
    }

    public void importButtonClick() throws IOException {
        ButtonType okay = new ButtonType("Okay", ButtonBar.ButtonData.OK_DONE);
        ButtonType cancel = new ButtonType("Cancel", ButtonBar.ButtonData.CANCEL_CLOSE);
        Alert alert = new Alert(Alert.AlertType.WARNING,
                "If you import, it will overwrite the existing data!",
                okay,
                cancel);
        alert.setTitle("WARNING!");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.orElse(cancel) == okay) {
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Import Rosters");
            fileChooser.getExtensionFilters().addAll(
                    new FileChooser.ExtensionFilter("DB File", "*.db")
            );
            File selectedFile = fileChooser.showOpenDialog(Main.homeStage);
            //File selectedFile = new File(String.valueOf(fileChooser.showOpenDialog(Main.homeStage).getAbsoluteFile()));
            if (selectedFile != null) {
                File toFile = new File(DBConnect.homeDir + "\\FootballRoster-main.db");
                DBConnect.closeConnection();
                Files.copy(selectedFile.toPath(), toFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
                DBConnect.connect();
                refreshInit();
            }
        }
    }

    public void exportButtonClick() throws IOException {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Export Rosters");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("DB File", "*.db")
        );
        File saveFile = fileChooser.showSaveDialog(Main.homeStage);
        File getFile = new File(DBConnect.homeDir + "\\FootballRoster-main.db");
        if (saveFile != null) {
            DBConnect.closeConnection();
            Files.copy(getFile.toPath(), saveFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
            DBConnect.connect();
        }
    }

    public void refreshInit() {
        try {
            DBRead.genYearsList();
            DBRead.genRostersList();
            DBRead.genPlayersList();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        if (Years.getYearsList().size() != 0) {
            yearLabel.setText(String.valueOf(getYearsList().get(yearIndex).getYearID()));
        } else {
            yearLabel.setText("Year");
        }

        if (Years.getYearsList().size() != 0) {
            try {
                teamNameLabel.setText(DBRead.getTeamName(Years.getYearsList().get(HomeController.yearIndex).getYearID()));
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else {
            teamNameLabel.setText("Team Name");
        }
        try {
            DBRead.genRostersList();
            DBRead.genPlayersList();
            DBRead.genYearsList();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        if (Years.getYearsList().size() != 0) {
            rosterTable.setItems(Rosters.getRostersListByYear(getYearsList().get(yearIndex).getYearID()));
        }
    }

    public ObservableList<Rosters> searchList(String search) {
        ObservableList<Rosters> returnList = FXCollections.observableArrayList();
        for (Rosters player : Rosters.getRostersListByYear(getYearsList().get(yearIndex).getYearID())) {
            if (player.getFirstName().toLowerCase().contains(search.toLowerCase())) returnList.add(player);
            if (player.getLastName().toLowerCase().contains(search.toLowerCase())) returnList.add(player);
        }
        return returnList;
    }

    public void searchButtonClick() {
        if (Years.getYearsList().size() != 0) rosterTable.setItems(searchList(searchField.getText()));
        else {
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("No Data");
            alter.setContentText("No data to search");
            alter.show();
        }
    }

    public void injuryListButtonClick() throws IOException {
        if (Years.getYearsList().size() != 0) {
            Parent root = FXMLLoader.load(getClass().getResource("InjuryList.fxml"));
            injuryListStage.getIcons().add(new Image(this.getClass().getResourceAsStream("white.png")));
            injuryListStage.setScene(new Scene(root, 350, 500));
            Main.homeStage.hide();
            injuryListStage.show();
        } else {
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("No Data");
            alter.setContentText("No data exists");
            alter.show();
        }
    }

    public void changePasswordButtonClick() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("ChangePassword.fxml"));
        changePasswordStage.getIcons().add(new Image(this.getClass().getResourceAsStream("white.png")));
        changePasswordStage.setScene(new Scene(root, 300, 300));
        Main.homeStage.hide();
        changePasswordStage.show();
    }
}
