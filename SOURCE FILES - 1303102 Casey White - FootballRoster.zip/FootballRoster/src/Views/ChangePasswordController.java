package Views;

import Database.DBUpdate;
import Main.Main;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;

public class ChangePasswordController {
    public TextField newPassTF;
    public TextField confirmTF;

    public void submitButtonClick() {
        if (newPassTF.getText().equals(confirmTF.getText())) {
            DBUpdate.changePassword(newPassTF.getText());
            HomeController.changePasswordStage.close();
            Main.homeStage.show();
        }
        else {
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("No Match");
            alter.setContentText("Passwords don't match");
            alter.show();
        }
    }

    public void cancelButtonClick() {
        HomeController.changePasswordStage.close();
        Main.homeStage.show();
    }

    public void newPassType(KeyEvent keyEvent) {
        if (!keyEvent.getCharacter().matches("[a-zA-Z0-9.&%\b\t]")) {
            if (newPassTF.getText().length() == 1) newPassTF.clear();
            else {
                newPassTF.setText(newPassTF.getText().substring(0, newPassTF.getText().length() - 1));
                newPassTF.positionCaret(newPassTF.getText().length());
            }
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Letters only");
            alter.setContentText("Please only input letters, numbers, &, %, or periods");
            alter.show();
        }
        if (newPassTF.getText().length() > 15) {
            newPassTF.setText(newPassTF.getText().substring(0, 15));
            newPassTF.positionCaret(newPassTF.getText().length());
        }
    }

    public void confirmType(KeyEvent keyEvent) {
        if (!keyEvent.getCharacter().matches("[a-zA-Z0-9.&%\b\t]")) {
            if (confirmTF.getText().length() == 1) confirmTF.clear();
            else {
                confirmTF.setText(confirmTF.getText().substring(0, confirmTF.getText().length() - 1));
                confirmTF.positionCaret(confirmTF.getText().length());
            }
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Letters only");
            alter.setContentText("Please only input letters, numbers, &, %, or periods");
            alter.show();
        }
        if (confirmTF.getText().length() > 15) {
            confirmTF.setText(confirmTF.getText().substring(0, 15));
            confirmTF.positionCaret(confirmTF.getText().length());
        }
    }
}
