package Views;

import Database.DBRead;
import Database.DBUpdate;
import Main.Main;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;

import java.net.URL;
import java.sql.SQLException;
import java.util.Collections;
import java.util.ResourceBundle;

import static Views.HomeController.selectedPlayer;
import static java.lang.Float.parseFloat;
import static java.lang.Integer.parseInt;

public class ModifyRosterPlayerController implements Initializable {
    public TextField jerseyNumberTF;
    public TextField firstNameTF;
    public TextField middleNameTF;
    public TextField lastNameTF;
    public DatePicker birthdayDP;
    public TextField heightTF;
    public TextField weightTF;
    public TextField benchTF;
    public TextField squatTF;
    public TextField fortyTimeTF;
    public ChoiceBox<String> positionCB;
    private int heightL;
    private static final ObservableList<String> positionsList = FXCollections.observableArrayList();

    private boolean checkNulls() {
        return !jerseyNumberTF.getText().isBlank() &&
                !firstNameTF.getText().isBlank() &&
                !lastNameTF.getText().isBlank() &&
                birthdayDP.getValue() != null &&
                !heightTF.getText().isBlank() &&
                !weightTF.getText().isBlank() &&
                !benchTF.getText().isBlank() &&
                !squatTF.getText().isBlank() &&
                !fortyTimeTF.getText().isBlank() &&
                !positionCB.getSelectionModel().isEmpty();
    }

    public void saveButtonClick() throws SQLException {
        if (checkNulls()) {
            DBUpdate.updateRosterPlayer(
                    selectedPlayer.getPlayerID(),
                    selectedPlayer.getRosterID(),
                    parseInt(jerseyNumberTF.getText()),
                    firstNameTF.getText(),
                    middleNameTF.getText(),
                    lastNameTF.getText(),
                    birthdayDP.getValue(),
                    heightL,
                    parseInt(weightTF.getText()),
                    parseInt(benchTF.getText()),
                    parseInt(squatTF.getText()),
                    parseFloat(fortyTimeTF.getText()),
                    positionCB.getSelectionModel().getSelectedItem()
            );
            DBUpdate.updateRosterAge(selectedPlayer.getPlayerID(), birthdayDP.getValue());
            HomeController.modifyPlayerStage.close();
            Main.homeStage.show();
        } else {
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Nulls");
            alter.setContentText("Only the middle name can be blank");
            alter.show();
        }
    }

    public void cancelButtonClick() {
        HomeController.modifyPlayerStage.close();
        Main.homeStage.show();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
            heightL = DBRead.getHeight(selectedPlayer.getRosterID());
        } catch (SQLException e) {
            e.printStackTrace();
        }
        jerseyNumberTF.setText(String.valueOf(selectedPlayer.getJerseyNumber()));
        firstNameTF.setText(selectedPlayer.getFirstName());
        try {
            middleNameTF.setText(DBRead.getMiddleName(selectedPlayer.getPlayerID()));
        } catch (SQLException e) {
            e.printStackTrace();
        }
        lastNameTF.setText(selectedPlayer.getLastName());
        try {
            birthdayDP.setValue(DBRead.getBirthday(selectedPlayer.getPlayerID()));
        } catch (SQLException e) {
            e.printStackTrace();
        }
        if (selectedPlayer.getHeight().equals("0'0")) {
            heightTF.setText("6'0");
        } else {
            heightTF.setText(selectedPlayer.getHeight());
        }
        weightTF.setText(String.valueOf(selectedPlayer.getWeight()));
        benchTF.setText(String.valueOf(selectedPlayer.getBenchPress()));
        squatTF.setText(String.valueOf(selectedPlayer.getSquat()));
        fortyTimeTF.setText(String.valueOf(selectedPlayer.getFortyTime()));
        positionsList.clear();
        Collections.addAll(positionsList, DepthChartController.getPositionArray());
        positionCB.setItems(positionsList);
        positionCB.setValue(selectedPlayer.getPosition());
    }

    public void addHeightButtonClick() {
        heightL++;
        String heightFeet = String.valueOf(heightL / 12);
        String heightInches = String.valueOf(heightL % 12);
        String height = heightFeet + "'" + heightInches;
        heightTF.setText(height);
    }

    public void decreaseHeightButtonClick() {
        heightL--;
        String heightFeet = String.valueOf(heightL / 12);
        String heightInches = String.valueOf(heightL % 12);
        String height = heightFeet + "'" + heightInches;
        heightTF.setText(height);
    }

    public void jerseyNumberTFType(KeyEvent keyEvent) {
        if (jerseyNumberTF.getText().length() > 2) {
            jerseyNumberTF.setText(jerseyNumberTF.getText().substring(0, 2));
            jerseyNumberTF.positionCaret(jerseyNumberTF.getText().length());
        }
        if (!keyEvent.getCharacter().matches("^$|(\t|\b|\\d*)")) {
            jerseyNumberTF.setText(jerseyNumberTF.getText().substring(0,jerseyNumberTF.getText().length() - 1));
            jerseyNumberTF.positionCaret(jerseyNumberTF.getText().length());
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Numbers only");
            alter.setContentText("Please only input numbers");
            alter.show();
        }
    }

    public void firstNameType(KeyEvent keyEvent) {
        if (!keyEvent.getCharacter().matches("[a-zA-Z .\b\t]")) {
            if (firstNameTF.getText().length() == 1) firstNameTF.clear();
            else {
                firstNameTF.setText(firstNameTF.getText().substring(0, firstNameTF.getText().length() - 1));
                firstNameTF.positionCaret(firstNameTF.getText().length());
            }
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Letters only");
            alter.setContentText("Please only input letters");
            alter.show();
        }
        if (firstNameTF.getText().length() > 15) {
            firstNameTF.setText(firstNameTF.getText().substring(0, 15));
            firstNameTF.positionCaret(firstNameTF.getText().length());
        }
    }

    public void middleNameType(KeyEvent keyEvent) {
        if (!keyEvent.getCharacter().matches("[a-zA-Z .\b\t]")) {
            if (middleNameTF.getText().length() == 1) middleNameTF.clear();
            else {
                middleNameTF.setText(middleNameTF.getText().substring(0, middleNameTF.getText().length() - 1));
                middleNameTF.positionCaret(middleNameTF.getText().length());
            }
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Letters only");
            alter.setContentText("Please only input letters");
            alter.show();
        }
        if (middleNameTF.getText().length() > 15) {
            middleNameTF.setText(middleNameTF.getText().substring(0, 15));
            middleNameTF.positionCaret(middleNameTF.getText().length());
        }
    }

    public void lastNameType(KeyEvent keyEvent) {
        if (!keyEvent.getCharacter().matches("[a-zA-Z .\b\t]")) {
            if (lastNameTF.getText().length() == 1) lastNameTF.clear();
            else {
                lastNameTF.setText(lastNameTF.getText().substring(0, lastNameTF.getText().length() - 1));
                lastNameTF.positionCaret(lastNameTF.getText().length());
            }
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Letters only");
            alter.setContentText("Please only input letters");
            alter.show();
        }
        if (lastNameTF.getText().length() > 15) {
            lastNameTF.setText(lastNameTF.getText().substring(0, 15));
            lastNameTF.positionCaret(lastNameTF.getText().length());
        }
    }

    public void weightType(KeyEvent keyEvent) {
        if (weightTF.getText().length() > 3) {
            weightTF.setText(weightTF.getText().substring(0, 3));
            weightTF.positionCaret(weightTF.getText().length());
        }
        if (!keyEvent.getCharacter().matches("^$|(\t|\b|\\d*)")) {
            weightTF.setText(weightTF.getText().substring(0,weightTF.getText().length() - 1));
            weightTF.positionCaret(weightTF.getText().length());
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Numbers only");
            alter.setContentText("Please only input numbers");
            alter.show();
        }
    }

    public void benchType(KeyEvent keyEvent) {
        if (benchTF.getText().length() > 3) {
            benchTF.setText(benchTF.getText().substring(0, 3));
            benchTF.positionCaret(benchTF.getText().length());
        }
        if (!keyEvent.getCharacter().matches("^$|(\t|\b|\\d*)")) {
            benchTF.setText(benchTF.getText().substring(0,benchTF.getText().length() - 1));
            benchTF.positionCaret(benchTF.getText().length());
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Numbers only");
            alter.setContentText("Please only input numbers");
            alter.show();
        }
    }

    public void squatType(KeyEvent keyEvent) {
        if (squatTF.getText().length() > 3) {
            squatTF.setText(squatTF.getText().substring(0, 3));
            squatTF.positionCaret(squatTF.getText().length());
        }
        if (!keyEvent.getCharacter().matches("^$|(\t|\b|\\d*)")) {
            squatTF.setText(squatTF.getText().substring(0,squatTF.getText().length() - 1));
            squatTF.positionCaret(squatTF.getText().length());
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Numbers only");
            alter.setContentText("Please only input numbers");
            alter.show();
        }
    }

    public void fortyTimeType() {
        if (fortyTimeTF.getText().length() > 4) {
            fortyTimeTF.setText(fortyTimeTF.getText().substring(0, 4));
            fortyTimeTF.positionCaret(fortyTimeTF.getText().length());
        }
        if (!fortyTimeTF.getText().matches("^$|(\\b\\d{0,8}\\.\\d{1,2})|\\b\\d*\\.|\\b\\d*")) {
            fortyTimeTF.clear();
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Format Error");
            alter.setContentText("Enrty must start with a digit, (ex. 0.23)");
            alter.show();
        }
    }

}
