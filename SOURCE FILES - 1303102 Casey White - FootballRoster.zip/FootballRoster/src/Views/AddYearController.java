package Views;

import Database.DBCreate;
import Database.DBRead;
import Main.Main;
import Structure.Years;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;

import java.sql.SQLException;

import static java.lang.Integer.parseInt;

public class AddYearController {
    public TextField yearTF;
    public TextField teamNameTF;

    private boolean checkNulls() {
        return !yearTF.getText().isBlank() && !teamNameTF.getText().isBlank();
    }

    public void saveButtonClick() throws SQLException {
        if (Years.getYearsList().size() == 0 || !DBRead.checkYearExist(parseInt(yearTF.getText()))) {
            if (checkNulls()) {
                if (Years.getYearsList().size() != 0 && parseInt(yearTF.getText()) < Years.getYearsList().get(HomeController.yearIndex).getYearID()) {
                    HomeController.yearIndex++;
                }
                DBCreate.addYear(parseInt(yearTF.getText()), teamNameTF.getText());
                DBRead.genYearsList();
                HomeController.addYearStage.close();
                Main.homeStage.show();
            } else {
                Alert alter = new Alert(Alert.AlertType.WARNING);
                alter.setHeaderText("Nulls");
                alter.setContentText("No fields can be blank");
                alter.show();
            }
        } else {
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Exists");
            alter.setContentText(yearTF.getText() + " Exists");
            alter.show();
        }
    }

    public void cancelButtonClick() {
        HomeController.addYearStage.close();
        Main.homeStage.show();
    }

    public void yearTFType(KeyEvent keyEvent) {
        if (yearTF.getText().length() > 4) {
            yearTF.setText(yearTF.getText().substring(0, 4));
            yearTF.positionCaret(yearTF.getText().length());
        }
        if (!keyEvent.getCharacter().matches("^$|(\t|\b|\\d*)")) {
            yearTF.setText(yearTF.getText().substring(0,yearTF.getText().length() - 1));
            yearTF.positionCaret(yearTF.getText().length());
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Numbers only");
            alter.setContentText("Please only input numbers");
            alter.show();
        }
    }

    public void teamNameTFType(KeyEvent keyEvent) {
        if (!keyEvent.getCharacter().matches("[a-zA-Z\b\t]")) {
            teamNameTF.setText(teamNameTF.getText().substring(0,teamNameTF.getText().length() - 1));
            teamNameTF.positionCaret(teamNameTF.getText().length());
            Alert alter = new Alert(Alert.AlertType.WARNING);
            alter.setHeaderText("Letters only");
            alter.setContentText("Please only input letters");
            alter.show();
        }
        if (teamNameTF.getText().length() > 30) {
            teamNameTF.setText(teamNameTF.getText().substring(0, 30));
            teamNameTF.positionCaret(teamNameTF.getText().length());
        }
    }
}
