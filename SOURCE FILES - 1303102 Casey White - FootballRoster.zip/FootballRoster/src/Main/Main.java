package Main;

import Database.*;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import java.sql.SQLException;

public class Main extends Application {

    public static Stage homeStage = new Stage();
    public static Stage loginStage = new Stage();

    @Override
    public void start(Stage primaryStage) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("/Views/Home.fxml"));
        homeStage.getIcons().add(new Image(this.getClass().getResourceAsStream("white.png")));
        homeStage.setScene(new Scene(root, 1000, 700));
        Parent root2 = FXMLLoader.load(getClass().getResource("/Views/Login.fxml"));
        loginStage.getIcons().add(new Image(this.getClass().getResourceAsStream("white.png")));
        loginStage.setScene(new Scene(root2, 300, 300));
        loginStage.show();
    }

    public static void main(String[] args) throws SQLException {
        DBConnect.connect();
        DBRead.checkYearTable();
        launch(args);
        DBConnect.closeConnection();
    }


}
