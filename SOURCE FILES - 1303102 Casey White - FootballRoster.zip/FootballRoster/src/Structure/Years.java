package Structure;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class Years {

    private int yearID;
    private String teamName;
    private static final ObservableList<Years> yearsList = FXCollections.observableArrayList();

    public Years(int yearID, String teamName) {
        this.yearID = yearID;
        this.teamName = teamName;
    }

    public int getYearID() { return yearID; }
    public void setYearID(int yearID) { this.yearID = yearID; }

    public String getTeamName() { return teamName; }
    public void setTeamName(String teamName) { this.teamName = teamName; }

    public static ObservableList<Years> getYearsList() { return yearsList; }
    public static void addYearsList(Years years) { yearsList.add(years); }
    public static void clearList() { yearsList.clear(); }

}
