package Structure;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class Rosters {

    private int rosterID;
    private int yearID;
    private String teamName;
    private int playerID;
    private String firstName;
    private String lastName;
    private int age;
    private int jerseyNumber;
    private String height;
    private int weight;
    private int benchPress;
    private int squat;
    private float fortyTime;
    private String position;
    private static final ObservableList<Rosters> rostersList = FXCollections.observableArrayList();

    public Rosters(
            int rosterID,
            int yearID,
            String teamName,
            int playerID,
            String firstName,
            String lastName,
            int age,
            int jerseyNumber,
            String height,
            int weight,
            int benchPress,
            int squat,
            float fortyTime,
            String position
    ) {
        this.rosterID = rosterID;
        this.yearID = yearID;
        this.teamName = teamName;
        this.playerID = playerID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
        this.jerseyNumber = jerseyNumber;
        this.height = height;
        this.weight = weight;
        this.benchPress = benchPress;
        this.squat = squat;
        this.fortyTime = fortyTime;
        this.position = position;
    }

    public int getRosterID() { return rosterID; }
    public void setRosterID(int rosterID) { this.rosterID = rosterID; }

    public int getYearID() { return yearID; }
    public void setYearID(int yearID) { this.yearID = yearID; }

    public String getTeamName() { return teamName; }
    public void setTeamName(String teamName) { this.teamName = teamName; }

    public int getPlayerID() { return playerID; }
    public void setPlayerID(int playerID) { this.playerID = playerID; }

    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }

    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }

    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }

    public int getJerseyNumber() { return jerseyNumber; }
    public void setJerseyNumber(int jerseyNumber) { this.jerseyNumber = jerseyNumber; }

    public String getHeight() { return height; }
    public void setHeight(String height) { this.height = height; }

    public int getWeight() { return weight; }
    public void setWeight(int weight) { this.weight = weight; }

    public int getBenchPress() { return benchPress; }
    public void setBenchPress(int benchPress) { this.benchPress = benchPress; }

    public int getSquat() { return squat; }
    public void setSquat(int squat) { this.squat = squat; }

    public float getFortyTime() { return fortyTime; }
    public void setFortyTime(float fortyTime) { this.fortyTime = fortyTime; }

    public String getPosition() { return position; }
    public void setPosition(String position) { this.position = position; }

    public static ObservableList<Rosters> getRostersList() { return rostersList; }
    public static void addRostersList(Rosters rosters) { rostersList.add(rosters); }
    public static void clearList() { rostersList.clear(); }

    public static ObservableList<Rosters> getRostersListByYear(int yearID) {
        ObservableList<Rosters> rostersListByYear = FXCollections.observableArrayList();
        for (Rosters player : rostersList) {
            if (player.yearID == yearID) rostersListByYear.add(player);
        }
        return rostersListByYear;
    }

    public static class Position {
        public static final String offense = "Offense";
        public static final String defense = "Defense";
        public static final String specialTeams = "Special Teams";

        public static class OffensePosition extends Position {
            public static final String QB = "QB";
            public static final String WR = "WR";
            public static final String TE = "TE";
            public static final String RB = "RB";
            public static final String FB = "FB";
            public static final String LT = "LT";
            public static final String LG = "LG";
            public static final String C = "C";
            public static final String RG = "RG";
            public static final String RT = "RT";
        }

        public static class DefensePosition extends Position {
            public static final String NOSE = "NOSE";
            public static final String DT = "DT";
            public static final String DE = "DE";
            public static final String OLB = "OLB";
            public static final String MLB = "MLB";
            public static final String CB = "CB";
            public static final String FS = "FS";
            public static final String SS = "SS";
        }

        public static class SpecialTeamPosition extends Position {
            public static final String K = "K";
            public static final String P = "P";
            public static final String H = "H";
            public static final String LS = "LS";
            public static final String PR = "PR";
            public static final String KR = "KR";
        }

    }

}
