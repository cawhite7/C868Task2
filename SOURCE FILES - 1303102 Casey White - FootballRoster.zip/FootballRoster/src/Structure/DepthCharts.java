package Structure;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class DepthCharts {
    private int depthChartID;
    private int rosterID;
    private int playerID;
    private String positionL;
    private int string;
    private String firstName;
    private String lastName;
    private int age;
    private String height;
    private int weight;
    private int bench;
    private int squat;
    private float fortyTime;
    private String position;
    private int jerseyNumber;
    private static final ObservableList<DepthCharts> depthChartList = FXCollections.observableArrayList();
    private static final ObservableList<DepthCharts> depthChartQBList = FXCollections.observableArrayList();
    private static final ObservableList<DepthCharts> depthChartWRList = FXCollections.observableArrayList();
    private static final ObservableList<DepthCharts> depthChartTEList = FXCollections.observableArrayList();
    private static final ObservableList<DepthCharts> depthChartRBList = FXCollections.observableArrayList();
    private static final ObservableList<DepthCharts> depthChartFBList = FXCollections.observableArrayList();
    private static final ObservableList<DepthCharts> depthChartLTList = FXCollections.observableArrayList();
    private static final ObservableList<DepthCharts> depthChartLGList = FXCollections.observableArrayList();
    private static final ObservableList<DepthCharts> depthChartCList = FXCollections.observableArrayList();
    private static final ObservableList<DepthCharts> depthChartRGList = FXCollections.observableArrayList();
    private static final ObservableList<DepthCharts> depthChartRTList = FXCollections.observableArrayList();
    private static final ObservableList<DepthCharts> depthChartNOSEList = FXCollections.observableArrayList();
    private static final ObservableList<DepthCharts> depthChartDTList = FXCollections.observableArrayList();
    private static final ObservableList<DepthCharts> depthChartDEList = FXCollections.observableArrayList();
    private static final ObservableList<DepthCharts> depthChartOLBList = FXCollections.observableArrayList();
    private static final ObservableList<DepthCharts> depthChartMLBList = FXCollections.observableArrayList();
    private static final ObservableList<DepthCharts> depthChartCBList = FXCollections.observableArrayList();
    private static final ObservableList<DepthCharts> depthChartFSList = FXCollections.observableArrayList();
    private static final ObservableList<DepthCharts> depthChartSSList = FXCollections.observableArrayList();
    private static final ObservableList<DepthCharts> depthChartKList = FXCollections.observableArrayList();
    private static final ObservableList<DepthCharts> depthChartPList = FXCollections.observableArrayList();
    private static final ObservableList<DepthCharts> depthChartHList = FXCollections.observableArrayList();
    private static final ObservableList<DepthCharts> depthChartLSList = FXCollections.observableArrayList();
    private static final ObservableList<DepthCharts> depthChartPRList = FXCollections.observableArrayList();
    private static final ObservableList<DepthCharts> depthChartKRList = FXCollections.observableArrayList();


    public DepthCharts(int depthChartID, int rosterID, int playerID, String positionL, int string, String firstName, String lastName, int age,
                       String height, int weight, int bench, int squat, float fortyTime, String position, int jerseyNumber) {
        this.depthChartID = depthChartID; this.rosterID = rosterID; this.playerID = playerID; this.positionL = positionL; this.string = string;
        this.firstName = firstName; this.lastName = lastName; this.age = age; this.height = height; this.weight = weight; this.bench = bench; this.squat = squat;
        this.fortyTime = fortyTime; this.position = position; this.jerseyNumber = jerseyNumber;
    }

    public int getDepthChartID() { return depthChartID; }
    public void setDepthChartID(int depthChartID) { this.depthChartID = depthChartID; }

    public int getRosterID() { return rosterID; }
    public void setRosterID(int rosterID) { this.rosterID = rosterID; }

    public int getPlayerID() { return playerID; }
    public void setPlayerID(int playerID) { this.playerID = playerID; }

    public String getPositionL() { return positionL; }
    public void setPositionL(String positionL) { this.positionL = positionL; }

    public int getString() { return string; }
    public void setString(int string) { this.string = string; }

    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }

    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }

    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }

    public String getHeight() { return height; }
    public void setHeight(String height) { this.height = height; }

    public int getWeight() { return weight; }
    public void setWeight(int weight) { this.weight = weight; }

    public int getBench() { return bench; }
    public void setBench(int bench) { this.bench = bench; }

    public int getSquat() { return squat; }
    public void setSquat(int squat) { this.squat = squat; }

    public float getFortyTime() { return fortyTime; }
    public void setFortyTime(float fortyTime) { this.fortyTime = fortyTime; }

    public String getPosition() { return position; }
    public void setPosition(String position) { this.position = position; }

    public int getJerseyNumber() { return jerseyNumber; }
    public void setJerseyNumber(int jerseyNumber) { this.jerseyNumber = jerseyNumber; }

    public static ObservableList<DepthCharts> getDepthChartList() { return depthChartList; }
    public static void addDepthChartList(DepthCharts player) { depthChartList.add(player); }
    public static void clearList() { depthChartList.clear(); }

    public static ObservableList<DepthCharts> getDepthChartQBList() { return depthChartQBList; }
    public static void addDepthChartQBList(DepthCharts player) { depthChartQBList.add(player); }
    public static void clearQBList() { depthChartQBList.clear(); }

    public static ObservableList<DepthCharts> getDepthChartWRList() { return depthChartWRList; }
    public static void addDepthChartWRList(DepthCharts player) { depthChartWRList.add(player); }
    public static void clearWRList() { depthChartWRList.clear(); }

    public static ObservableList<DepthCharts> getDepthChartTEList() { return depthChartTEList; }
    public static void addDepthChartTEList(DepthCharts player) { depthChartTEList.add(player); }
    public static void clearTEList() { depthChartTEList.clear(); }

    public static ObservableList<DepthCharts> getDepthChartRBList() { return depthChartRBList; }
    public static void addDepthChartRBList(DepthCharts player) { depthChartRBList.add(player); }
    public static void clearRBList() { depthChartRBList.clear(); }

    public static ObservableList<DepthCharts> getDepthChartFBList() { return depthChartFBList; }
    public static void addDepthChartFBList(DepthCharts player) { depthChartFBList.add(player); }
    public static void clearFBList() { depthChartFBList.clear(); }

    public static ObservableList<DepthCharts> getDepthChartLTList() { return depthChartLTList; }
    public static void addDepthChartLTList(DepthCharts player) { depthChartLTList.add(player); }
    public static void clearLTList() { depthChartLTList.clear(); }

    public static ObservableList<DepthCharts> getDepthChartLGList() { return depthChartLGList; }
    public static void addDepthChartLGList(DepthCharts player) { depthChartLGList.add(player); }
    public static void clearLGList() { depthChartLGList.clear(); }

    public static ObservableList<DepthCharts> getDepthChartCList() { return depthChartCList; }
    public static void addDepthChartCList(DepthCharts player) { depthChartCList.add(player); }
    public static void clearCList() { depthChartCList.clear(); }

    public static ObservableList<DepthCharts> getDepthChartRGList() { return depthChartRGList; }
    public static void addDepthChartRGList(DepthCharts player) { depthChartRGList.add(player); }
    public static void clearRGList() { depthChartRGList.clear(); }

    public static ObservableList<DepthCharts> getDepthChartRTList() { return depthChartRTList; }
    public static void addDepthChartRTList(DepthCharts player) { depthChartRTList.add(player); }
    public static void clearRTList() { depthChartRTList.clear(); }

    public static ObservableList<DepthCharts> getDepthChartNOSEList() { return depthChartNOSEList; }
    public static void addDepthChartNOSEList(DepthCharts player) { depthChartNOSEList.add(player); }
    public static void clearNOSEList() { depthChartNOSEList.clear(); }

    public static ObservableList<DepthCharts> getDepthChartDTList() { return depthChartDTList; }
    public static void addDepthChartDTList(DepthCharts player) { depthChartDTList.add(player); }
    public static void clearDTList() { depthChartDTList.clear(); }

    public static ObservableList<DepthCharts> getDepthChartDEList() { return depthChartDEList; }
    public static void addDepthChartDEList(DepthCharts player) { depthChartDEList.add(player); }
    public static void clearDEList() { depthChartDEList.clear(); }

    public static ObservableList<DepthCharts> getDepthChartOLBList() { return depthChartOLBList; }
    public static void addDepthChartOLBList(DepthCharts player) { depthChartOLBList.add(player); }
    public static void clearOLBList() { depthChartOLBList.clear(); }

    public static ObservableList<DepthCharts> getDepthChartMLBList() { return depthChartMLBList; }
    public static void addDepthChartMLBList(DepthCharts player) { depthChartMLBList.add(player); }
    public static void clearMLBList() { depthChartMLBList.clear(); }

    public static ObservableList<DepthCharts> getDepthChartCBList() { return depthChartCBList; }
    public static void addDepthChartCBList(DepthCharts player) { depthChartCBList.add(player); }
    public static void clearCBList() { depthChartCBList.clear(); }

    public static ObservableList<DepthCharts> getDepthChartFSList() { return depthChartFSList; }
    public static void addDepthChartFSList(DepthCharts player) { depthChartFSList.add(player); }
    public static void clearFSList() { depthChartFSList.clear(); }

    public static ObservableList<DepthCharts> getDepthChartSSList() { return depthChartSSList; }
    public static void addDepthChartSSList(DepthCharts player) { depthChartSSList.add(player); }
    public static void clearSSList() { depthChartSSList.clear(); }

    public static ObservableList<DepthCharts> getDepthChartKList() { return depthChartKList; }
    public static void addDepthChartKList(DepthCharts player) { depthChartKList.add(player); }
    public static void clearKList() { depthChartKList.clear(); }

    public static ObservableList<DepthCharts> getDepthChartPList() { return depthChartPList; }
    public static void addDepthChartPList(DepthCharts player) { depthChartPList.add(player); }
    public static void clearPList() { depthChartPList.clear(); }

    public static ObservableList<DepthCharts> getDepthChartHList() { return depthChartHList; }
    public static void addDepthChartHList(DepthCharts player) { depthChartHList.add(player); }
    public static void clearHList() { depthChartHList.clear(); }

    public static ObservableList<DepthCharts> getDepthChartLSList() { return depthChartLSList; }
    public static void addDepthChartLSList(DepthCharts player) { depthChartLSList.add(player); }
    public static void clearLSList() { depthChartLSList.clear(); }

    public static ObservableList<DepthCharts> getDepthChartPRList() { return depthChartPRList; }
    public static void addDepthChartPRList(DepthCharts player) { depthChartPRList.add(player); }
    public static void clearPRList() { depthChartPRList.clear(); }

    public static ObservableList<DepthCharts> getDepthChartKRList() { return depthChartKRList; }
    public static void addDepthChartKRList(DepthCharts player) { depthChartKRList.add(player); }
    public static void clearKRList() { depthChartKRList.clear(); }

    public static void clearAllPositionLists() {
        clearQBList();
        clearWRList();
        clearTEList();
        clearRBList();
        clearFBList();
        clearLTList();
        clearLGList();
        clearCList();
        clearRTList();
        clearRGList();
        clearNOSEList();
        clearDTList();
        clearDEList();
        clearOLBList();
        clearMLBList();
        clearCBList();
        clearFSList();
        clearSSList();
        clearKList();
        clearPList();
        clearKRList();
        clearPRList();
        clearHList();
        clearLSList();
    }

    public static void genDepthChartByPosition() {
        clearAllPositionLists();
        for (DepthCharts player : DepthCharts.getDepthChartList()) {
            switch (player.getPositionL()) {
                case "QB" -> addDepthChartQBList(player);
                case "WR" -> addDepthChartWRList(player);
                case "TE" -> addDepthChartTEList(player);
                case "RB" -> addDepthChartRBList(player);
                case "FB" -> addDepthChartFBList(player);
                case "LT" -> addDepthChartLTList(player);
                case "LG" -> addDepthChartLGList(player);
                case "C" -> addDepthChartCList(player);
                case "RG" -> addDepthChartRGList(player);
                case "RT" -> addDepthChartRTList(player);
                case "NOSE" -> addDepthChartNOSEList(player);
                case "DT" -> addDepthChartDTList(player);
                case "DE" -> addDepthChartDEList(player);
                case "OLB" -> addDepthChartOLBList(player);
                case "MLB" -> addDepthChartMLBList(player);
                case "CB" -> addDepthChartCBList(player);
                case "FS" -> addDepthChartFSList(player);
                case "SS" -> addDepthChartSSList(player);
                case "K" -> addDepthChartKList(player);
                case "P" -> addDepthChartPList(player);
                case "H" -> addDepthChartHList(player);
                case "LS" -> addDepthChartLSList(player);
                case "PR" -> addDepthChartPRList(player);
                case "KR" -> addDepthChartKRList(player);
                default -> throw new IllegalArgumentException("Invalid Position: " + player.getPositionL());
            }
        }
    }

    public static ObservableList<DepthCharts> getPositionList(String position) {
        switch (position) {
            case "QB" -> {
                return getDepthChartQBList();
            }
            case "WR" -> {
                return getDepthChartWRList();
            }
            case "TE" -> {
                return getDepthChartTEList();
            }
            case "RB" -> {
                return getDepthChartRBList();
            }
            case "FB" -> {
                return getDepthChartFBList();
            }
            case "LT" -> {
                return getDepthChartLTList();
            }
            case "LG" -> {
                return getDepthChartLGList();
            }
            case "C" -> {
                return getDepthChartCList();
            }
            case "RG" -> {
                return getDepthChartRGList();
            }
            case "RT" -> {
                return getDepthChartRTList();
            }
            case "NOSE" -> {
                return getDepthChartNOSEList();
            }
            case "DT" -> {
                return getDepthChartDTList();
            }
            case "DE" -> {
                return getDepthChartDEList();
            }
            case "OLB" -> {
                return getDepthChartOLBList();
            }
            case "MLB" -> {
                return getDepthChartMLBList();
            }
            case "CB" -> {
                return getDepthChartCBList();
            }
            case "FS" -> {
                return getDepthChartFSList();
            }
            case "SS" -> {
                return getDepthChartSSList();
            }
            case "K" -> {
                return getDepthChartKList();
            }
            case "P" -> {
                return getDepthChartPList();
            }
            case "H" -> {
                return getDepthChartHList();
            }
            case "LS" -> {
                return getDepthChartLSList();
            }
            case "PR" -> {
                return getDepthChartPRList();
            }
            case "KR" -> {
                return getDepthChartKRList();
            }
            default -> throw new IllegalArgumentException("Invalid Position: " + position);
        }
    }
/*
    public static void addDepthChartByPosition(DepthCharts player, String position) {
        switch (position) {
            case "QB" -> {
                addDepthChartQBList(player);
            }
            case "WR" -> {
                addDepthChartWRList(player);
            }
            case "TE" -> {
                addDepthChartTEList(player);
            }
            case "RB" -> {
                addDepthChartRBList(player);
            }
            case "FB" -> {
                addDepthChartFBList(player);
            }
            case "LT" -> {
                addDepthChartLTList(player);
            }
            case "LG" -> {
                addDepthChartLGList(player);
            }
            case "C" -> {
                addDepthChartCList(player);
            }
            case "RG" -> {
                addDepthChartRGList(player);
            }
            case "RT" -> {
                addDepthChartRTList(player);
            }
            case "NOSE" -> {
                addDepthChartNOSEList(player);
            }
            case "DT" -> {
                addDepthChartDTList(player);
            }
            case "DE" -> {
                addDepthChartDEList(player);
            }
            case "OLB" -> {
                addDepthChartOLBList(player);
            }
            case "MLB" -> {
                addDepthChartMLBList(player);
            }
            case "CB" -> {
                addDepthChartCBList(player);
            }
            case "FS" -> {
                addDepthChartFSList(player);
            }
            case "SS" -> {
                addDepthChartSSList(player);
            }
            case "K" -> {
                addDepthChartKList(player);
            }
            case "P" -> {
                addDepthChartPList(player);
            }
            case "H" -> {
                addDepthChartHList(player);
            }
            case "LS" -> {
                addDepthChartLSList(player);
            }
            case "PR" -> {
                addDepthChartPRList(player);
            }
            case "KR" -> {
                addDepthChartKRList(player);
            }
            default -> throw new IllegalArgumentException("Invalid Position: " + position);
        }
    }

    public static ObservableList<DepthCharts> getStartingOffenseLine() {
        ObservableList<DepthCharts> oLine = FXCollections.observableArrayList();
        for (DepthCharts player : getDepthChartLTList()) {
            if (player.getString() == 1) oLine.add(player);
        }
        for (DepthCharts player : getDepthChartLGList()) {
            if (player.getString() == 1) oLine.add(player);
        }
        for (DepthCharts player : getDepthChartCList()) {
            if (player.getString() == 1) oLine.add(player);
        }
        for (DepthCharts player : getDepthChartRGList()) {
            if (player.getString() == 1) oLine.add(player);
        }
        for (DepthCharts player : getDepthChartRTList()) {
            if (player.getString() == 1) oLine.add(player);
        }
        return oLine;
    }
 */

}
