package Structure;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class Injuries {
    private int injuryID;
    private int rosterID;
    private int jerseyNumber;
    private String firstName;
    private String lastName;
    private String position;
    private static final ObservableList<Injuries> injuryList = FXCollections.observableArrayList();

    public Injuries(int injuryID, int rosterID, int jerseyNumber, String firstName, String lastName, String position) {
        this.injuryID = injuryID;
        this.rosterID = rosterID;
        this.jerseyNumber = jerseyNumber;
        this.firstName = firstName;
        this.lastName = lastName;
        this.position = position;
    }

    public int getInjuryID() { return injuryID; }
    public void setInjuryID(int injuryID) { this.injuryID = injuryID; }

    public int getRosterID() { return rosterID; }
    public void setRosterID(int rosterID) { this.rosterID = rosterID; }

    public int getJerseyNumber() { return jerseyNumber; }
    public void setJerseyNumber(int jerseyNumber) { this.jerseyNumber = jerseyNumber; }

    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }

    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }

    public String getPosition() { return position; }
    public void setPosition(String position) { this.position = position; }

    public static ObservableList<Injuries> getInjuryList() { return injuryList; }
    public static void addInjuryList(Injuries player) { injuryList.add(player); }
    public static void clearList() { injuryList.clear(); }

}
