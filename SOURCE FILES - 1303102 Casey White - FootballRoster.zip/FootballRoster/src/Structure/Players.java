package Structure;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.time.LocalDate;

public class Players {

    private int playerID;
    private String firstName;
    private String middleName;
    private String lastName;
    private LocalDate birthDay;
    private int age;
    private static final ObservableList<Players> playersList = FXCollections.observableArrayList();

    public Players(int playerID, String firstName, String middleName, String lastName, LocalDate birthDay, int age) {
        this.playerID = playerID;
        this.firstName = firstName;
        this.middleName = middleName;
        this.lastName = lastName;
        this.birthDay = birthDay;
        this.age = age;
    }

    public int getPlayerID() { return playerID; }
    public void setPlayerID(int playerID) { this.playerID = playerID; }

    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }

    public String getMiddleName() { return middleName; }
    public void setMiddleName(String middleName) { this.middleName = middleName; }

    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }

    public LocalDate getBirthDay() { return birthDay; }
    public void setBirthDay(LocalDate birthDay) { this.birthDay = birthDay; }

    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }

    public static ObservableList<Players> getPlayersList() { return playersList; }
    public static void addPlayersList(Players players) { playersList.add(players); }
    public static void clearList() { playersList.clear(); }

}
