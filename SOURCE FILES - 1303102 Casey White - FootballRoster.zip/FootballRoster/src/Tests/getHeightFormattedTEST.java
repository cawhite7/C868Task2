package Tests;

import org.junit.jupiter.api.Test;

import static java.lang.StrictMath.abs;
import static org.junit.jupiter.api.Assertions.*;

class getHeightFormattedTEST {

    @Test
    public void testHeightFormattedZERO() {
        int inches = 0;
        String heightFeet = String.valueOf(abs(inches) / 12);
        String heightInches = String.valueOf(abs(inches) % 12);
        assertEquals("0'0", (heightFeet + "'" + heightInches));
    }

    @Test
    public void testHeightFormattedONE() {
        int inches = 1;
        String heightFeet = String.valueOf(abs(inches) / 12);
        String heightInches = String.valueOf(abs(inches) % 12);
        assertEquals("0'1", (heightFeet + "'" + heightInches));
    }

    @Test
    public void testHeightFormattedTWELVE() {
        int inches = 12;
        String heightFeet = String.valueOf(abs(inches) / 12);
        String heightInches = String.valueOf(abs(inches) % 12);
        assertEquals("1'0", (heightFeet + "'" + heightInches));
    }

    @Test
    public void testHeightFormattedREALISTIC() {
        int inches = 71;
        String heightFeet = String.valueOf(abs(inches) / 12);
        String heightInches = String.valueOf(abs(inches) % 12);
        assertEquals("5'11", (heightFeet + "'" + heightInches));
    }

    @Test
    public void testHeightFormattedNEGATIVE() {
        int inches = -20;
        String heightFeet = String.valueOf(abs(inches) / 12);
        String heightInches = String.valueOf(abs(inches) % 12);
        assertEquals("1'8", (heightFeet + "'" + heightInches));
    }

}